"""Render a captioned demo video from demo.db (no voice; add your own narration, or use the captions).
Usage: python -m scripts.make_video [--db demo.db] [--out demo_video.mp4]   (needs Pillow + ffmpeg)"""
import argparse, json, math, os, re, sqlite3, subprocess, tempfile
from datetime import timedelta
from PIL import Image, ImageDraw, ImageFont

from aqi_agent.util import parse

ap = argparse.ArgumentParser(); ap.add_argument("--db", default="demo.db"); ap.add_argument("--out", default="demo_video.mp4")
ap.add_argument("--eval", default="docs/EVAL_REPORT.md"); a = ap.parse_args()
c = sqlite3.connect(a.db); c.row_factory = sqlite3.Row
W, H = 1920, 1080
BG, FG, MUT, ACC, RED, GRN, BOX = "#0f1217", "#e8eaed", "#8b93a1", "#4fc3f7", "#ef5350", "#66bb6a", "#1a2029"
FD = "/usr/share/fonts/truetype/dejavu/"
F = lambda n, b=False: ImageFont.truetype(FD + ("DejaVuSans-Bold.ttf" if b else "DejaVuSans.ttf") if n != "mono" else FD + "DejaVuSansMono.ttf", 0)


def font(size, bold=False, mono=False):
    f = "DejaVuSansMono.ttf" if mono else ("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf")
    return ImageFont.truetype(FD + f, size)


def wrap(d, text, f, width):
    lines, cur = [], ""
    for w in text.split():
        t = (cur + " " + w).strip()
        if d.textlength(t, font=f) <= width: cur = t
        else: lines.append(cur); cur = w
    return lines + [cur] if cur else lines


def scene(title, caption, body=None, sub=None):
    im = Image.new("RGB", (W, H), BG); d = ImageDraw.Draw(im)
    d.text((90, 60), title, font=font(60, True), fill=FG)
    if sub: d.text((90, 140), sub, font=font(30), fill=MUT)
    if body: body(d, im)
    d.rectangle([0, H - 150, W, H], fill="#0a0c10")
    y = H - 135
    for ln in wrap(d, caption, font(38), W - 180)[:3]:
        d.text((90, y), ln, font=font(38), fill=FG); y += 46
    return im


def box(d, xy, text, fill=BOX, outline=ACC, size=32, color=FG):
    d.rounded_rectangle(xy, 14, fill=fill, outline=outline, width=3)
    x0, y0, x1, y1 = xy; f = font(size, True)
    lines = text.split("\n"); h = len(lines) * (size + 8); y = (y0 + y1) / 2 - h / 2
    for ln in lines:
        d.text(((x0 + x1) / 2 - d.textlength(ln, font=f) / 2, y), ln, font=f, fill=color); y += size + 8


scenes = []

# 1 title
def b1(d, im):
    d.text((90, 330), "Watches hourly PM2.5 from OpenAQ for 5 cities,", font=font(46), fill=FG)
    d.text((90, 395), "and only speaks when something is worth knowing.", font=font(46), fill=ACC)
    d.text((90, 560), "Learned anomaly + change-point detection  ·  dedup memory  ·  human messages  ·  full audit trail", font=font(30), fill=MUT)
scenes.append((7, scene("Proactive Air Quality Insight Agent", "A backend that decides, on its own, when and what to tell a user about air quality. Silence is the default.", b1)))

# 2 architecture
def b2(d, im):
    xs = [90, 440, 790, 1140, 1490]; labels = ["OpenAQ v3\nhourly PM2.5", "Ingest\nhistory + quality\nflags", "Learned model\nper station\n+ CUSUM", "Dedup policy\nper-user memory", "Message\n+ audit log"]
    for i, (x, l) in enumerate(zip(xs, labels)):
        box(d, (x, 330, x + 300, 530), l, size=30)
        if i < 4: d.text((x + 305, 410), "→", font=font(50, True), fill=ACC)
    d.text((90, 640), "Candidates: spike · trend · elevated · recovery      Actions: send · suppress · none", font=font(34), fill=FG)
    d.text((90, 710), "Every evaluation is logged with its inputs and checks, fired or not.", font=font(34), fill=MUT)
scenes.append((14, scene("How it works", "Hourly ingest, a model fitted per station, a dedup state machine per user, then a message. Every decision is logged for debugging.", b2)))

# 3 learned normals
rows = []
for sid, nm in (("delhi", "Delhi"), ("bengaluru", "Bengaluru"), ("london", "London"), ("reykjavik", "Reykjavik")):
    r = c.execute("SELECT detector_json FROM decisions WHERE station_id=? AND detector_json LIKE '%baseline_aqi%' ORDER BY id DESC LIMIT 1", (sid,)).fetchone()
    m = json.loads(r[0])["model"]; thr = m["baseline_aqi"] * math.exp(3.25 * m["sigma_log"])
    rows.append((nm, m["baseline_aqi"], thr))
def b3(d, im):
    d.text((90, 230), "City", font=font(32, True), fill=MUT); d.text((520, 230), "Learned typical AQI", font=font(32, True), fill=MUT); d.text((1000, 230), "AQI needed for a spike alert", font=font(32, True), fill=MUT)
    for i, (nm, base, thr) in enumerate(rows):
        y = 300 + i * 130
        d.text((90, y), nm, font=font(48, True), fill=FG)
        d.text((520, y), f"{base:.0f}", font=font(48), fill=ACC)
        d.text((1000, y), f"≈ {thr:.0f}  (+{thr - base:.0f})", font=font(48), fill=RED)
        d.rectangle([90, y + 78, 90 + min(base, 300) * 1.9 / 1.9 * 2.2, y + 88], fill=ACC)
scenes.append((16, scene("Each city gets its own learned “normal”", "A spike alert needs roughly +88 AQI points in Delhi but only +25 in London. Thresholds come from each station's own fitted baseline and noise, not one global number.", b3, "fitted from the trailing 7 days; user sensitivity scales the bar further")))

# 4 plateau timeline chart
best = None
for u in c.execute("SELECT DISTINCT user_id FROM decisions"):
    rs = c.execute("SELECT id,station_id,data_ts,candidate,action,reason FROM decisions WHERE user_id=? AND candidate IS NOT NULL ORDER BY id", (u[0],)).fetchall()
    for i, r in enumerate(rs):
        if r["action"] == "send" and r["candidate"] != "recovery":
            seq = [r]
            for x in rs[i + 1:]:
                seq.append(x)
                if x["action"] == "send": break
            if best is None or len(seq) > len(best[1]): best = (u[0], seq)
user, seq = best; st = seq[0]["station_id"]
t0, t1 = parse(seq[0]["data_ts"]) - timedelta(hours=18), parse(seq[-1]["data_ts"]) + timedelta(hours=8)
rd = c.execute("SELECT ts,aqi FROM readings WHERE station_id=? AND flag='ok' AND ts>=? AND ts<=? ORDER BY ts", (st, t0.strftime("%Y-%m-%dT%H:%M:%SZ"), t1.strftime("%Y-%m-%dT%H:%M:%SZ"))).fetchall()
pts = [(parse(r["ts"]), r["aqi"]) for r in rd]
notif = c.execute("SELECT message FROM notifications WHERE decision_id=?", (seq[0]["id"],)).fetchone()["message"]
def b4(d, im):
    x0, y0, x1, y1 = 120, 230, 1800, 700
    lo, hi = min(v for _, v in pts), max(v for _, v in pts); span = (pts[-1][0] - pts[0][0]).total_seconds()
    X = lambda t: x0 + (t - pts[0][0]).total_seconds() / span * (x1 - x0); Y = lambda v: y1 - (v - lo) / max(hi - lo, 1) * (y1 - y0)
    d.rectangle([x0, y0, x1, y1], outline="#2a313c")
    d.line([(X(t), Y(v)) for t, v in pts], fill="#9fb3c8", width=4)
    for r in seq:
        t = parse(r["data_ts"]); v = next((v for tt, v in pts if tt == t), None)
        if v is None: continue
        col = GRN if r["action"] == "send" and r["candidate"] == "recovery" else RED if r["action"] == "send" else "#6b7280"
        d.ellipse([X(t) - 11, Y(v) - 11, X(t) + 11, Y(v) + 11], fill=col)
    d.text((x0, y1 + 12), "red = notification sent   green = recovery sent   grey = flagged but suppressed (duplicate)", font=font(28), fill=MUT)
    y = y1 + 70
    for ln in wrap(d, "“" + notif + "”", font(32), 1680)[:3]:
        d.text((x0, y), ln, font=font(32), fill=ACC); y += 40
nsup = sum(1 for r in seq if r["action"] == "suppress")
scenes.append((22, scene("A long bad stretch becomes ONE message", f"The detector flagged this episode {len(seq) - 1} times; {user} got one notification, {nsup} duplicates were suppressed, then a single recovery message.", b4, f"{st.replace('_', ' ').title()} · simulated data")))

# 5 glitch rejected
g = None
for r in c.execute("SELECT id,station_id,data_ts,detector_json FROM decisions WHERE candidate IS NULL AND detector_json LIKE '%\"z_ok\":true%' ORDER BY id"):
    dj = json.loads(r["detector_json"]); sp = dj.get("checks", {}).get("spike", {})
    if sp.get("z_ok") and not sp.get("prev_hour_confirms") and dj["metrics"]["aqi"] > 200: g = (r, dj); break
def b5(d, im):
    r, dj = g; m = dj["metrics"]; sp = dj["checks"]["spike"]
    d.text((90, 240), f"{r['station_id'].title()} · {r['data_ts']}", font=font(36), fill=MUT)
    d.text((90, 300), f"AQI {m['aqi']:.0f}", font=font(110, True), fill=RED)
    d.text((620, 335), f"z-score now = {m['z_now']:.1f}   previous hour = {m['z_prev']:.1f}", font=font(38), fill=FG)
    y = 520
    for k, v in sp.items():
        d.text((120, y), ("✔ " if v else "✘ ") + k, font=font(44, True, True), fill=GRN if v else RED); y += 72
    d.text((820, 560), "No alert sent.", font=font(64, True), fill=FG)
    d.text((820, 650), "One extreme hour isn't a trend:", font=font(36), fill=MUT)
    d.text((820, 700), "the previous hour must be elevated too.", font=font(36), fill=MUT)
scenes.append((16, scene("A one-hour sensor glitch is rejected", "A single reading of AQI 500 did not fire an alert, because the hour before it was normal. Every check is stored so you can see why.", b5)))

# 6 messages
def pickmsgs():
    out = []
    for kind in ("spike", "trend", "recovery", "elevated"):
        r = c.execute("SELECT n.user_id,n.kind,n.message FROM notifications n WHERE n.kind=? ORDER BY LENGTH(n.message) DESC LIMIT 1 OFFSET 1", (kind,)).fetchone() or \
            c.execute("SELECT user_id,kind,message FROM notifications WHERE kind=? LIMIT 1", (kind,)).fetchone()
        if r: out.append(r)
    return out
msgs = pickmsgs()
def b6(d, im):
    y = 230
    for r in msgs[:3]:
        d.rounded_rectangle([90, y, 1830, y + 200], 18, fill=BOX, outline="#2a313c", width=2)
        d.text((120, y + 14), f"{r['kind']} · {r['user_id']}", font=font(26, True), fill=ACC)
        yy = y + 62
        for ln in wrap(d, r["message"], font(32), 1660)[:3]:
            d.text((120, yy), ln, font=font(32), fill=FG); yy += 38
        y += 235
scenes.append((20, scene("Messages with context and one next action", "Each message references past context (earlier alerts, highest reading since…) and ends with one clear action tailored to the user.", b6, "template text shown; set ANTHROPIC_API_KEY for LLM-written wording")))

# 7 observability
def b7(d, im):
    items = [("Fitted model", "baseline, noise σ, time-of-day shape"), ("Every check", "pass/fail with the numbers behind it"), ("24-hour window", "readings, expected values, z-scores"),
             ("Policy state", "before and after, plus the suppression reason"), ("The message", "and the context it was written from")]
    d.text((90, 230), "GET /api/decisions/{id}", font=font(48, True, True), fill=ACC)
    y = 340
    for a_, b_ in items:
        d.text((120, y), "•  " + a_, font=font(44, True), fill=FG); d.text((620, y + 6), b_, font=font(36), fill=MUT); y += 95
    d.text((120, y + 40), "Suppressed reasons: duplicate_ongoing_episode · flap_cooldown_recent_alert · worsening_but_in_cooldown · stale_data", font=font(28), fill=MUT)
scenes.append((16, scene("Debugging a bad or missing nudge", "Every evaluation is logged, including the ones where nothing was sent, with the model, the checks and the user's memory state.", b7)))

# 8 evaluation
ev = open(a.eval).read()
def g1(label): m = re.search(r"\| " + re.escape(label) + r"[^|]*\| ([^|]+) \|", ev); return m.group(1).strip() if m else "?"
def b8(d, im):
    items = [("Spikes caught", g1("Recall: spike")), ("Trends caught", g1("Recall: trend")), ("Recoveries caught", g1("Recall: recovery")), ("Precision", g1("Precision")),
             ("Alerts / city-day", g1("Alerts per station-day")), ("Naive “AQI>100” alerter", g1("Naive").replace(" per station-day", "/day"))]
    for i, (k, v) in enumerate(items):
        x, y = 90 + (i % 2) * 900, 240 + (i // 2) * 200
        d.rounded_rectangle([x, y, x + 840, y + 170], 18, fill=BOX, outline="#2a313c", width=2)
        d.text((x + 30, y + 20), k, font=font(30), fill=MUT); d.text((x + 30, y + 70), v, font=font(52, True), fill=ACC if i < 5 else RED)
scenes.append((18, scene("Replay evaluation", "Replaying simulated history through the same pipeline. These numbers are from simulated data with known ground truth, because OpenAQ wasn't reachable when this was built.", b8, "28 days × 5 cities · glitches and stuck sensors produced no alerts")))

# 9 outro
def b9(d, im):
    lines = ["pip install -r requirements.txt", "python -m aqi_agent demo", "python -m aqi_agent serve", "python -m aqi_agent check-openaq   # with your OpenAQ key"]
    for i, l in enumerate(lines): d.text((120, 300 + i * 90), "$ " + l, font=font(44, False, True), fill=GRN)
    d.text((120, 720), "Detector tuned on simulated data · live OpenAQ client to be verified with a real key", font=font(30), fill=MUT)
scenes.append((10, scene("Try it", "Everything runs offline with the demo command; add an OpenAQ key to run live. See DECISIONS.md for the design trade-offs.", b9)))

tmp = tempfile.mkdtemp(); clips = []
for i, (secs, im) in enumerate(scenes):
    p = f"{tmp}/s{i}.png"; im.save(p); o = f"{tmp}/s{i}.mp4"
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-loop", "1", "-t", str(secs), "-i", p, "-vf", f"fade=t=in:st=0:d=0.5,fade=t=out:st={secs - 0.5}:d=0.5,format=yuv420p",
                    "-r", "30", "-c:v", "libx264", "-preset", "veryfast", o], check=True)
    clips.append(o)
open(f"{tmp}/list.txt", "w").write("".join(f"file '{c_}'\n" for c_ in clips))
subprocess.run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0", "-i", f"{tmp}/list.txt", "-c", "copy", a.out], check=True)
for i, (_, im) in enumerate(scenes): im.save(f"{os.path.dirname(os.path.abspath(a.out))}/_scene{i + 1}.png") if os.environ.get("KEEP_SCENES") else None
print("wrote", a.out, sum(s for s, _ in scenes), "seconds")
