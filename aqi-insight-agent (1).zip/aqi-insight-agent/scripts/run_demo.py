"""Replay a simulated month through the full pipeline; write demo.db + docs/NOTIFICATION_HISTORY.md + docs/EVAL_REPORT.md."""
from __future__ import annotations
import os
from collections import defaultdict

from aqi_agent.evaluate import format_report, run_sim_eval


def run(days=28, seed=7, db="demo.db", out="docs"):
    if os.path.exists(db):
        os.remove(db)
    conn, rep, truth, rows = run_sim_eval(days, seed, db_path=db)
    os.makedirs(out, exist_ok=True)
    with open(f"{out}/EVAL_REPORT.md", "w") as f:
        f.write(format_report(rep, f"Evaluation: simulated replay ({days} days, seed {seed})") + "\n")
    notes = conn.execute("SELECT n.*, u.name uname FROM notifications n JOIN users u ON u.id=n.user_id ORDER BY n.ts, n.id").fetchall()
    L = ["# Notification history (simulated replay)", "",
         f"{len(notes)} notifications sent to {len({n['user_id'] for n in notes})} users over {days} days "
         f"(7 days burn-in used for model fitting). Each row links to its decision id; "
         f"open `/api/decisions/<id>` in the running service for the full trace.", ""]
    by = defaultdict(list)
    for n in notes:
        by[n["user_id"]].append(n)
    for uid, ns in by.items():
        L += [f"## {uid}", "", "| time (UTC) | kind | AQI | message | decision |", "|---|---|---|---|---|"]
        for n in ns:
            L.append(f"| {n['ts']} | {n['kind']} | {n['aqi']} | {n['message']} | #{n['decision_id']} |")
        L.append("")
    sup = conn.execute("SELECT reason, COUNT(*) c FROM decisions WHERE action='suppress' GROUP BY reason ORDER BY c DESC").fetchall()
    L += ["## What dedup swallowed", "", "| reason | count |", "|---|---|"] + [f"| {r['reason']} | {r['c']} |" for r in sup]
    with open(f"{out}/NOTIFICATION_HISTORY.md", "w") as f:
        f.write("\n".join(L) + "\n")
    print(format_report(rep, "Evaluation"))
    print(f"\nwrote {db}, {out}/NOTIFICATION_HISTORY.md, {out}/EVAL_REPORT.md")


if __name__ == "__main__":
    run()
