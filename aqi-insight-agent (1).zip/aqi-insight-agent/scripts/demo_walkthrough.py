"""Paced, narrated walkthrough for screen recording.  Usage: python -m scripts.demo_walkthrough [--db demo.db] [--no-pause]
Press Enter between sections (unless --no-pause)."""
import argparse, json, sqlite3

ap = argparse.ArgumentParser(); ap.add_argument("--db", default="demo.db"); ap.add_argument("--no-pause", action="store_true")
a = ap.parse_args()
c = sqlite3.connect(a.db); c.row_factory = sqlite3.Row


def pause(msg=""):
    if msg: print(f"\n  >> SAY: {msg}")
    if not a.no_pause: input("\n[Enter for next section] ")


def hdr(t): print("\n" + "=" * 78 + f"\n{t}\n" + "=" * 78)


hdr("1. Different cities, different learned 'normal'")
for sid in ("delhi", "bengaluru", "london", "reykjavik"):
    r = c.execute("SELECT detector_json FROM decisions WHERE station_id=? AND detector_json LIKE '%baseline_aqi%' ORDER BY id DESC LIMIT 1", (sid,)).fetchone()
    m = json.loads(r[0])["model"]
    import math
    thr = m["baseline_aqi"] * math.exp(3.25 * m["sigma_log"])
    print(f"  {sid:10s} typical AQI ~{m['baseline_aqi']:>6}  noise sigma(log) {m['sigma_log']:<6} -> a spike alert needs roughly AQI {thr:.0f} (+{thr - m['baseline_aqi']:.0f})")
pause("Each station gets its own fitted baseline and noise level, so 'unusual' is judged against that city's own normal, not one global threshold.")

hdr("2. A bad stretch: one message, the rest suppressed")
best = None
for u in c.execute("SELECT DISTINCT user_id FROM decisions"):
    rows = c.execute("SELECT id,data_ts,candidate,action,reason FROM decisions WHERE user_id=? AND candidate IS NOT NULL ORDER BY id", (u[0],)).fetchall()
    for i, r in enumerate(rows):
        if r["action"] == "send" and r["candidate"] != "recovery":
            dup = 0
            for x in rows[i + 1:]:
                if x["action"] == "suppress": dup += 1
                else: break
            if best is None or dup > best[0]: best = (dup, u[0], rows[i:i + dup + 2])
dup, user, seq = best
print(f"  user: {user}")
for r in seq:
    d = json.loads(c.execute("SELECT detector_json FROM decisions WHERE id=?", (r["id"],)).fetchone()[0])
    m = d.get("metrics", {})
    print(f"  {r['data_ts']}  AQI {m.get('aqi')!s:>6}  z={m.get('z_now')!s:>5}  {r['candidate']:9s} -> {r['action']:8s} {r['reason']}")
n = c.execute("SELECT message FROM notifications WHERE decision_id=?", (seq[0]["id"],)).fetchone()
print(f"\n  NOTIFICATION: {n['message']}")
pause(f"The detector flagged this episode in {dup + 1} separate hours. The user got ONE notification; the others were logged as suppressed duplicates, until recovery.")

hdr("3. A one-hour sensor glitch is rejected")
g = None
for r in c.execute("SELECT id,station_id,data_ts,detector_json FROM decisions WHERE candidate IS NULL AND detector_json LIKE '%\"z_ok\":true%' ORDER BY id"):
    d = json.loads(r["detector_json"]); sp = d.get("checks", {}).get("spike", {})
    if sp.get("z_ok") and not sp.get("prev_hour_confirms") and d["metrics"]["aqi"] > 200:
        g = (r, d); break
if g:
    r, d = g
    print(f"  {r['station_id']} @ {r['data_ts']}: AQI {d['metrics']['aqi']} (z={d['metrics']['z_now']}) but previous hour z={d['metrics']['z_prev']}")
    print("  spike checks:", json.dumps(d["checks"]["spike"]))
    print(f"  decision id {r['id']}  ->  /api/decisions/{r['id']}")
pause("A huge reading alone isn't enough: the previous hour must also be elevated. Every check is stored for debugging.")

hdr("4. Recovery message")
n = c.execute("SELECT user_id,ts,message FROM notifications WHERE kind='recovery' ORDER BY id DESC LIMIT 1").fetchone()
print(f"  {n['user_id']} @ {n['ts']}\n  {n['message']}")
pause("Recovery fires once, only if we alerted in that episode.")

hdr("5. What dedup swallowed overall")
for r in c.execute("SELECT reason, COUNT(*) n FROM decisions WHERE action='suppress' GROUP BY reason ORDER BY n DESC"):
    print(f"  {r['reason']:32s} {r['n']}")
s = c.execute("SELECT COUNT(*) FROM notifications").fetchone()[0]
print(f"  notifications actually sent: {s}")
pause("Now open the dashboard at http://127.0.0.1:8000 and the eval report.")
