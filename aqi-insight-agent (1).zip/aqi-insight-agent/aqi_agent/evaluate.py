"""Replay harness: feed history hour-by-hour through the *same* pipeline, then score against labels.

Labels come from either the simulator's ground truth, or (for real OpenAQ data) simple model-free
heuristics (heuristic_labels). Reports caught vs missed "interesting moments", false positives
(split by cause), detection latency, notifications/day, and a naive stateless-threshold comparison.
"""
from __future__ import annotations
import statistics
import tempfile
from datetime import timedelta

from .config import CITIES, USERS
from .db import connect, seed_config
from .engine import evaluate_station
from .ingest import reflag_stuck, upsert_readings
from .simulator import TruthEvent, generate_series
from .util import floor_hour, iso, parse

BURN_IN_H = 168


def replay(readings_by_station: dict, cities=CITIES, users=USERS, db_path: str | None = None,
           burn_in_h: int = BURN_IN_H, use_llm: bool = False, log=None):
    db_path = db_path or tempfile.mktemp(suffix=".db")
    conn = connect(db_path)
    seed_config(conn, cities, users)
    for sid, rows in readings_by_station.items():
        upsert_readings(conn, sid, rows)
        reflag_stuck(conn, sid)
    for st in conn.execute("SELECT * FROM stations").fetchall():
        rows = readings_by_station.get(st["id"])
        if not rows:
            continue
        us = conn.execute("SELECT * FROM users WHERE station_id=?", (st["id"],)).fetchall()
        t0, t1 = rows[0][0] + timedelta(hours=burn_in_h), rows[-1][0]
        now = t0
        while now <= t1:
            evaluate_station(conn, st, us, now, None, use_llm=use_llm)
            now += timedelta(hours=1)
        if log:
            log(f"replayed {st['id']}: {int((t1 - t0).total_seconds() // 3600)} hours")
    return conn


def heuristic_labels(rows) -> list:
    """Model-free labels for real data: confirmed sharp jumps, sustained climbs. (kind, start, end)"""
    vals = [(floor_hour(t), v) for t, v in rows]
    from .aqi import pm25_to_aqi
    a = [(t, pm25_to_aqi(v)) for t, v in vals if 0 <= v <= 1000]
    ev, i = [], 12
    while i < len(a) - 2:
        t, v = a[i]
        base = statistics.median(x for _, x in a[i - 8:i - 3])
        if v >= 1.5 * base and v - base >= 25 and a[i + 1][1] >= 1.35 * base:
            j = i
            while j < len(a) - 1 and a[j + 1][1] >= 1.2 * base:
                j += 1
            ev.append(TruthEvent("spike", t, a[j][0]))
            i = j + 6
            continue
        w = [x for _, x in a[i - 4:i + 1]]
        if all(w[k + 1] >= w[k] for k in range(4)) and w[-1] - w[0] >= max(20, 0.3 * w[0]):
            j = i
            while j < len(a) - 1 and a[j + 1][1] >= 0.8 * w[-1]:
                j += 1
            ev.append(TruthEvent("trend", a[i - 4][0], a[j][0], a[i][0]))
            i = j + 6
            continue
        i += 1
    return ev


def score(conn, truth: dict, ref_user_by_station: dict, rows_by_station: dict, burn_in_h=BURN_IN_H) -> dict:
    """truth: station_id -> list[TruthEvent]. Scores one reference user per station."""
    H = timedelta(hours=1)
    rep = {"per_kind": {}, "false_positives": [], "latencies_h": []}
    tp = fp = n_alerts = 0
    caught = {"spike": [0, 0], "trend": [0, 0], "recovery": [0, 0]}  # caught, total
    naive_total = station_days = 0.0
    sent_total = cand_total = supp_total = 0
    for sid, events in truth.items():
        uid = ref_user_by_station[sid]
        notifs = [dict(r) for r in conn.execute(
            "SELECT ts,kind,aqi FROM notifications WHERE user_id=? ORDER BY ts", (uid,))]
        for n in notifs:
            n["t"] = parse(n["ts"])
        pos = [e for e in events if e.kind in ("spike", "trend")]
        neg = [e for e in events if e.kind in ("glitch", "stuck")]
        # --- worsening alerts / recovery alerts
        for n in notifs:
            n_alerts += 1
            if n["kind"] == "recovery":
                ok = any(e.end - H <= n["t"] <= e.end + 12 * H for e in pos)
                cause = None if ok else "recovery_without_matching_event"
            else:
                ok = any(e.start <= n["t"] <= e.end + H for e in pos)
                cause = None
                if not ok:
                    cause = next((e.kind for e in neg if e.start - H <= n["t"] <= e.end + 4 * H), "unexplained_noise")
            if ok:
                tp += 1
            else:
                fp += 1
                rep["false_positives"].append({"station": sid, "ts": n["ts"], "kind": n["kind"], "aqi": n["aqi"], "cause": cause})
        # --- recall
        for e in pos:
            lim = (e.ramp_end + 4 * H) if e.kind == "trend" else (e.start + 4 * H)
            hits = [n for n in notifs if n["kind"] != "recovery" and e.start <= n["t"] <= lim]
            caught[e.kind][1] += 1
            if hits:
                caught[e.kind][0] += 1
                rep["latencies_h"].append((hits[0]["t"] - e.start).total_seconds() / 3600)
                caught["recovery"][1] += 1
                if any(n["kind"] == "recovery" and e.end - H <= n["t"] <= e.end + 12 * H for n in notifs):
                    caught["recovery"][0] += 1
        rows = rows_by_station[sid]
        eval_rows = rows[burn_in_h:]
        station_days += len(eval_rows) / 24
        from .aqi import pm25_to_aqi
        naive_total += sum(1 for _, v in eval_rows if 0 <= v <= 1000 and pm25_to_aqi(v) > 100)
    for row in conn.execute("SELECT candidate,action FROM decisions").fetchall():
        if row["candidate"]:
            cand_total += 1
            sent_total += row["action"] == "send"
            supp_total += row["action"] == "suppress"
    rep["recall"] = {k: {"caught": c, "total": t, "rate": round(c / t, 2) if t else None} for k, (c, t) in caught.items()}
    rep["precision"] = round(tp / n_alerts, 2) if n_alerts else None
    rep["alerts"] = {"total": n_alerts, "true_positive": tp, "false_positive": fp,
                     "per_station_day": round(n_alerts / station_days, 2) if station_days else None}
    rep["latency_h"] = {"median": statistics.median(rep["latencies_h"]) if rep["latencies_h"] else None,
                        "max": max(rep["latencies_h"]) if rep["latencies_h"] else None}
    rep["dedup"] = {"candidate_hours_all_users": cand_total, "sent": sent_total, "suppressed": supp_total}
    rep["naive_threshold_aqi_gt_100"] = {"notifications": int(naive_total),
                                         "per_station_day": round(naive_total / station_days, 2) if station_days else None}
    return rep


def run_sim_eval(days: int = 28, seed: int = 7, db_path: str | None = None, log=print):
    start = floor_hour(parse("2026-09-01T00:00:00Z"))
    hours = days * 24
    rows, truth = {}, {}
    for i, c in enumerate(CITIES):
        rows[c["id"]], truth[c["id"]] = generate_series(c, start, hours, seed=seed * 100 + i)
    conn = replay(rows, db_path=db_path, log=log)
    ref = {}
    for u in USERS:
        ref.setdefault(u["station"], u["id"])
    return conn, score(conn, truth, ref, rows), truth, rows


def format_report(rep: dict, title: str) -> str:
    r = rep["recall"]
    L = [f"# {title}", "",
         "| Metric | Value |", "|---|---|"]
    for k in ("spike", "trend", "recovery"):
        L.append(f"| Recall: {k} | {r[k]['caught']}/{r[k]['total']} ({r[k]['rate']}) |")
    L += [f"| Precision (alerts matching a real event) | {rep['precision']} |",
          f"| Alerts sent (reference users) | {rep['alerts']['total']} (TP {rep['alerts']['true_positive']}, FP {rep['alerts']['false_positive']}) |",
          f"| Alerts per station-day | {rep['alerts']['per_station_day']} |",
          f"| Detection latency (hours after onset), median / max | {rep['latency_h']['median']} / {rep['latency_h']['max']} |",
          f"| Dedup: candidate hours -> sent / suppressed (all users) | {rep['dedup']['candidate_hours_all_users']} -> {rep['dedup']['sent']} / {rep['dedup']['suppressed']} |",
          f"| Naive 'AQI>100 every hour' alerter would send | {rep['naive_threshold_aqi_gt_100']['notifications']} ({rep['naive_threshold_aqi_gt_100']['per_station_day']} per station-day) |", ""]
    if rep["false_positives"]:
        L += ["## False positives", "", "| station | time (UTC) | kind | AQI | likely cause |", "|---|---|---|---|---|"]
        for f in rep["false_positives"]:
            L.append(f"| {f['station']} | {f['ts']} | {f['kind']} | {f['aqi']} | {f['cause']} |")
    return "\n".join(L)
