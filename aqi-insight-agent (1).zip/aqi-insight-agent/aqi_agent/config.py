from __future__ import annotations
import os
from dataclasses import dataclass

# Five cities with very different baselines. `sim` is only used by the offline simulator.
CITIES = [
    {"id": "delhi", "name": "Delhi", "lat": 28.6139, "lon": 77.2090, "tz": "Asia/Kolkata",
     "sim": {"mean": 90, "amp": 0.30, "noise": 0.28}},
    {"id": "bengaluru", "name": "Bengaluru", "lat": 12.9716, "lon": 77.5946, "tz": "Asia/Kolkata",
     "sim": {"mean": 24, "amp": 0.25, "noise": 0.25}},
    {"id": "london", "name": "London", "lat": 51.5074, "lon": -0.1278, "tz": "Europe/London",
     "sim": {"mean": 9, "amp": 0.20, "noise": 0.24}},
    {"id": "reykjavik", "name": "Reykjavik", "lat": 64.1466, "lon": -21.9426, "tz": "Atlantic/Reykjavik",
     "sim": {"mean": 4, "amp": 0.12, "noise": 0.28}},
    {"id": "los_angeles", "name": "Los Angeles", "lat": 34.0522, "lon": -118.2437, "tz": "America/Los_Angeles",
     "sim": {"mean": 11, "amp": 0.28, "noise": 0.24}},
]

# Hard-coded demo users. `sensitivity` > 1 lowers the bar for "unusual" (all z thresholds / sensitivity).
USERS = [
    {"id": "asha-delhi", "name": "Asha", "station": "delhi", "sensitivity": 1.0, "activity": "runner"},
    {"id": "vikram-delhi", "name": "Vikram", "station": "delhi", "sensitivity": 0.8, "activity": "commuter"},
    {"id": "meera-blr", "name": "Meera", "station": "bengaluru", "sensitivity": 1.0, "activity": "parent"},
    {"id": "tom-london", "name": "Tom", "station": "london", "sensitivity": 1.2, "activity": "cyclist"},
    {"id": "sigrun-rey", "name": "Sigrun", "station": "reykjavik", "sensitivity": 1.0, "activity": "runner"},
    {"id": "dana-la", "name": "Dana", "station": "los_angeles", "sensitivity": 1.3, "activity": "runner"},
]


@dataclass
class Settings:
    db_path: str = "aqi_agent.db"
    source: str = "openaq"          # openaq | none (dashboard only)
    openaq_key: str | None = None
    anthropic_key: str | None = None
    llm_model: str = "claude-haiku-5-5"
    scheduler: bool = True
    minute: int = 5                 # run at HH:05 every hour

    @classmethod
    def from_env(cls) -> "Settings":
        e = os.environ.get
        return cls(
            db_path=e("AQI_DB", "aqi_agent.db"),
            source=e("AQI_SOURCE", "openaq"),
            openaq_key=e("OPENAQ_API_KEY"),
            anthropic_key=e("ANTHROPIC_API_KEY"),
            llm_model=e("AQI_LLM_MODEL", "claude-haiku-5-5"),
            scheduler=e("AQI_SCHEDULER", "on") != "off",
            minute=int(e("AQI_MINUTE", "5")),
        )
