"""PM2.5 (µg/m³) -> US EPA AQI (2024 breakpoints) and band helpers.

OpenAQ returns raw concentrations, not AQI, so we convert ourselves.
"""
from __future__ import annotations
import math

# (conc_lo, conc_hi, aqi_lo, aqi_hi) -- EPA PM2.5 table as revised in 2024
_BP = [
    (0.0, 9.0, 0, 50),
    (9.1, 35.4, 51, 100),
    (35.5, 55.4, 101, 150),
    (55.5, 125.4, 151, 200),
    (125.5, 225.4, 201, 300),
    (225.5, 325.4, 301, 500),
]
BAND_NAMES = ["Good", "Moderate", "Unhealthy for sensitive groups",
              "Unhealthy", "Very unhealthy", "Hazardous"]
_BAND_TOP = [50, 100, 150, 200, 300]


def pm25_to_aqi(pm25: float) -> int:
    if pm25 is None or math.isnan(pm25) or pm25 < 0:
        raise ValueError(f"invalid pm25: {pm25}")
    c = math.floor(pm25 * 10 + 1e-9) / 10  # EPA truncates to 0.1
    for lo, hi, ilo, ihi in _BP:
        if c <= hi:
            return int(round((ihi - ilo) / (hi - lo) * (c - lo) + ilo))
    return 500


def band_of(aqi: float) -> int:
    for i, top in enumerate(_BAND_TOP):
        if aqi <= top:
            return i
    return 5


def band_name(aqi: float) -> str:
    return BAND_NAMES[band_of(aqi)]
