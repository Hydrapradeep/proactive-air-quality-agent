"""FastAPI service: hourly scheduler + observability endpoints + tiny HTML dashboard."""
from __future__ import annotations
import html
import json
import threading
from contextlib import asynccontextmanager
from datetime import datetime, timedelta

from fastapi import Depends, FastAPI, HTTPException
from fastapi.responses import HTMLResponse

from .config import CITIES, USERS, Settings
from .db import connect, seed_config
from .pipeline import make_source, tick
from .util import iso, parse, utcnow

settings = Settings.from_env()
_lock = threading.Lock()


def run_tick():
    with _lock:
        conn = connect(settings.db_path)
        try:
            tick(conn, make_source(settings), settings)
        finally:
            conn.close()


@asynccontextmanager
async def lifespan(app: FastAPI):
    conn = connect(settings.db_path)
    seed_config(conn, CITIES, USERS)
    conn.close()
    sched = None
    if settings.scheduler:
        from apscheduler.schedulers.background import BackgroundScheduler
        sched = BackgroundScheduler(timezone="UTC")
        sched.add_job(run_tick, "cron", minute=settings.minute, id="hourly_tick")
        sched.add_job(run_tick, "date", run_date=datetime.now(), id="startup_tick")  # fill history right away
        sched.start()
    yield
    if sched:
        sched.shutdown(wait=False)


app = FastAPI(title="Proactive Air Quality Insight Agent", lifespan=lifespan)


def db():
    conn = connect(settings.db_path)
    try:
        yield conn
    finally:
        conn.close()


def _rows(cur):
    return [dict(r) for r in cur.fetchall()]


@app.get("/api/health")
def health(conn=Depends(db)):
    last = conn.execute("SELECT * FROM ingest_runs ORDER BY id DESC LIMIT 1").fetchone()
    return {"status": "ok", "source": settings.source, "last_ingest": dict(last) if last else None}


@app.post("/api/tick")
def manual_tick():
    run_tick()
    return {"ok": True}


@app.get("/api/stations")
def stations(conn=Depends(db)):
    return _rows(conn.execute(
        "SELECT s.*, (SELECT COUNT(*) FROM readings r WHERE r.station_id=s.id) AS n_readings, "
        "(SELECT MAX(ts) FROM readings r WHERE r.station_id=s.id) AS latest_reading FROM stations s"))


@app.get("/api/readings/{station_id}")
def readings(station_id: str, hours: int = 72, conn=Depends(db)):
    since = iso(utcnow() - timedelta(hours=hours))
    return _rows(conn.execute("SELECT ts,pm25,aqi,flag FROM readings WHERE station_id=? AND ts>=? ORDER BY ts",
                              (station_id, since)))


@app.get("/api/ingest_runs")
def ingest_runs(limit: int = 50, conn=Depends(db)):
    return _rows(conn.execute("SELECT * FROM ingest_runs ORDER BY id DESC LIMIT ?", (limit,)))


@app.get("/api/decisions")
def decisions(station_id: str | None = None, user_id: str | None = None, action: str | None = None,
              candidate_only: bool = False, limit: int = 100, conn=Depends(db)):
    q, a = "SELECT id,data_ts,station_id,user_id,candidate,action,reason,notification_id FROM decisions WHERE 1=1", []
    for col, val in (("station_id", station_id), ("user_id", user_id), ("action", action)):
        if val:
            q += f" AND {col}=?"
            a.append(val)
    if candidate_only:
        q += " AND candidate IS NOT NULL"
    return _rows(conn.execute(q + " ORDER BY id DESC LIMIT ?", (*a, limit)))


@app.get("/api/decisions/{decision_id}")
def decision(decision_id: int, conn=Depends(db)):
    r = conn.execute("SELECT * FROM decisions WHERE id=?", (decision_id,)).fetchone()
    if not r:
        raise HTTPException(404, "no such decision")
    d = dict(r)
    for k in ("detector_json", "window_json", "state_before_json", "state_after_json"):
        d[k[:-5]] = json.loads(d.pop(k)) if d[k] else None
    if d["notification_id"]:
        n = conn.execute("SELECT * FROM notifications WHERE id=?", (d["notification_id"],)).fetchone()
        d["notification"] = dict(n)
        d["notification"]["context"] = json.loads(d["notification"].pop("context_json"))
    return d


@app.get("/api/notifications")
def notifications(user_id: str | None = None, limit: int = 100, conn=Depends(db)):
    q, a = "SELECT id,ts,user_id,station_id,kind,band,aqi,message,message_source,decision_id FROM notifications", []
    if user_id:
        q += " WHERE user_id=?"
        a.append(user_id)
    return _rows(conn.execute(q + " ORDER BY ts DESC, id DESC LIMIT ?", (*a, limit)))


@app.get("/api/state")
def state(conn=Depends(db)):
    return {r["user_id"]: json.loads(r["state_json"]) for r in conn.execute("SELECT * FROM user_state")}


def _spark(conn, sid, hours=96, w=560, h=70):
    rows = conn.execute("SELECT ts,aqi FROM readings WHERE station_id=? AND flag='ok' ORDER BY ts DESC LIMIT ?",
                        (sid, hours)).fetchall()[::-1]
    if len(rows) < 2:
        return ""
    ts = [parse(r["ts"]) for r in rows]
    vs = [r["aqi"] for r in rows]
    lo, hi, t0, t1 = min(vs), max(vs), ts[0], ts[-1]
    span = max((t1 - t0).total_seconds(), 1)
    X = lambda t: (t - t0).total_seconds() / span * w
    Y = lambda v: h - 4 - (v - lo) / max(hi - lo, 1) * (h - 10)
    pts = " ".join(f"{X(t):.1f},{Y(v):.1f}" for t, v in zip(ts, vs))
    dots = "".join(f"<circle cx='{X(parse(n['ts'])):.1f}' cy='{Y(n['aqi']):.1f}' r='4' fill='{'#2a9d3a' if n['kind']=='recovery' else '#d33'}'>"
                   f"<title>{html.escape(n['kind'])} @ {n['ts']}</title></circle>"
                   for n in conn.execute("SELECT ts,kind,aqi FROM notifications WHERE station_id=? AND ts>=?",
                                         (sid, iso(t0))) if lo <= n["aqi"] <= hi)
    return f"<svg width='{w}' height='{h}'><polyline fill='none' stroke='#456' stroke-width='1.5' points='{pts}'/>{dots}</svg>"


@app.get("/", response_class=HTMLResponse)
def dashboard(conn=Depends(db)):
    e = html.escape
    out = ["<html><head><title>AQI Insight Agent</title><meta http-equiv='refresh' content='120'><style>"
           "body{font:14px system-ui;margin:20px;max-width:1100px}table{border-collapse:collapse;width:100%}"
           "td,th{border-bottom:1px solid #ddd;padding:4px 8px;text-align:left;vertical-align:top}"
           ".send{background:#fff3f0}.suppress{color:#777}h2{margin-top:28px}code{background:#eee;padding:1px 4px}"
           "</style></head><body><h1>Air Quality Insight Agent</h1>"
           "<p>Red dots = alerts sent, green = recovery. Click a decision id for the full trace "
           "(<code>/api/decisions/{id}</code>).</p>"]
    for s in conn.execute("SELECT * FROM stations"):
        last = conn.execute("SELECT ts,aqi FROM readings WHERE station_id=? AND flag='ok' ORDER BY ts DESC LIMIT 1",
                            (s["id"],)).fetchone()
        out.append(f"<h3>{e(s['name'])} <small>(sensor {s['sensor_id']} {e(s['location_name'] or '')})</small> "
                   f"{'AQI ' + str(last['aqi']) + ' @ ' + last['ts'] if last else 'no data'}</h3>{_spark(conn, s['id'])}")
    out.append("<h2>Notifications</h2><table><tr><th>time (UTC)</th><th>user</th><th>kind</th><th>AQI</th><th>message</th><th>why</th></tr>")
    for n in conn.execute("SELECT * FROM notifications ORDER BY ts DESC, id DESC LIMIT 40"):
        out.append(f"<tr><td>{n['ts']}</td><td>{e(n['user_id'])}</td><td>{n['kind']}</td><td>{n['aqi']}</td>"
                   f"<td>{e(n['message'])}</td><td><a href='/api/decisions/{n['decision_id']}'>#{n['decision_id']}</a></td></tr>")
    out.append("</table><h2>Recent decisions (candidates only; suppressed ones are what dedup swallowed)</h2>"
               "<table><tr><th>id</th><th>data time</th><th>user</th><th>candidate</th><th>action</th><th>reason</th></tr>")
    for d in conn.execute("SELECT id,data_ts,user_id,candidate,action,reason FROM decisions "
                          "WHERE candidate IS NOT NULL ORDER BY id DESC LIMIT 60"):
        out.append(f"<tr class='{d['action']}'><td><a href='/api/decisions/{d['id']}'>{d['id']}</a></td><td>{d['data_ts']}</td>"
                   f"<td>{e(d['user_id'])}</td><td>{d['candidate']}</td><td>{d['action']}</td><td>{d['reason']}</td></tr>")
    out.append("</table><h2>Per-user memory</h2><pre>")
    for r in conn.execute("SELECT * FROM user_state"):
        out.append(f"{e(r['user_id'])}: {e(r['state_json'])}")
    out.append("</pre></body></html>")
    return "".join(out)
