"""CLI:  python -m aqi_agent <serve|tick|demo|eval|check-openaq>"""
from __future__ import annotations
import argparse
import os
import sys


def main(argv=None):
    ap = argparse.ArgumentParser(prog="aqi_agent")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("serve"); s.add_argument("--host", default="127.0.0.1"); s.add_argument("--port", type=int, default=8000)
    sub.add_parser("tick")
    d = sub.add_parser("demo"); d.add_argument("--days", type=int, default=28); d.add_argument("--seed", type=int, default=7)
    d.add_argument("--db", default="demo.db"); d.add_argument("--out", default="docs")
    e = sub.add_parser("eval"); e.add_argument("--days", type=int, default=28); e.add_argument("--seed", type=int, default=7)
    e.add_argument("--source", choices=["sim", "db"], default="sim"); e.add_argument("--db", default="aqi_agent.db")
    sub.add_parser("check-openaq")
    a = ap.parse_args(argv)

    from .config import Settings
    settings = Settings.from_env()
    if a.cmd == "serve":
        import uvicorn
        uvicorn.run("aqi_agent.app:app", host=a.host, port=a.port)
    elif a.cmd == "tick":
        from .db import connect, seed_config
        from .config import CITIES, USERS
        from .pipeline import make_source, tick
        conn = connect(settings.db_path); seed_config(conn, CITIES, USERS)
        tick(conn, make_source(settings), settings)
    elif a.cmd == "check-openaq":
        from .config import CITIES
        from .openaq import OpenAQClient
        from .util import utcnow
        from datetime import timedelta
        c = OpenAQClient(settings.openaq_key)
        for city in CITIES:
            sid, name = c.find_pm25_sensor(city["lat"], city["lon"])
            rows = c.hourly(sid, utcnow() - timedelta(hours=24), utcnow())
            print(f"{city['name']:12s} sensor {sid} ({name}): {len(rows)} hourly rows, latest={rows[-1] if rows else None}")
    elif a.cmd == "eval":
        from .evaluate import format_report, run_sim_eval
        if a.source == "sim":
            _, rep, _, _ = run_sim_eval(a.days, a.seed)
            print(format_report(rep, f"Simulated replay ({a.days} days, seed {a.seed})"))
        else:
            from .db import connect
            from .evaluate import heuristic_labels, replay, score
            from .util import parse
            src = connect(a.db)
            rows = {}
            for st in src.execute("SELECT id FROM stations"):
                r = src.execute("SELECT ts,pm25 FROM readings WHERE station_id=? ORDER BY ts", (st["id"],)).fetchall()
                if len(r) > 200:
                    rows[st["id"]] = [(parse(x["ts"]), x["pm25"]) for x in r]
            conn = replay(rows, log=print)
            truth = {sid: heuristic_labels(r[168:]) for sid, r in rows.items()}
            from .config import USERS
            ref = {}
            for u in USERS: ref.setdefault(u["station"], u["id"])
            rep = score(conn, truth, ref, rows)
            print(format_report(rep, "Replay of stored OpenAQ history (heuristic labels)"))
    elif a.cmd == "demo":
        from scripts.run_demo import run
        run(a.days, a.seed, a.db, a.out)


if __name__ == "__main__":
    sys.exit(main())
