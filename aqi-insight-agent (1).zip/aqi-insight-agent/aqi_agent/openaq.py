"""Thin OpenAQ v3 client (https://docs.openaq.org). Needs a free API key (X-API-Key header).

NOTE: written against the documented v3 shapes (/locations, /sensors/{id}/hours). Verified here only
against a mocked transport (tests/test_openaq.py); run `python -m aqi_agent check-openaq` with your key.
"""
from __future__ import annotations
import time
from datetime import datetime, timedelta

import httpx

from .util import iso, parse, floor_hour

BASE = "https://api.openaq.org/v3"
PM25_PARAM_ID = 2


class OpenAQClient:
    def __init__(self, api_key: str | None, transport: httpx.BaseTransport | None = None, timeout: float = 30):
        headers = {"X-API-Key": api_key} if api_key else {}
        self.http = httpx.Client(base_url=BASE, headers=headers, timeout=timeout, transport=transport)

    def _get(self, path: str, params: dict) -> dict:
        for attempt in range(4):
            r = self.http.get(path, params=params)
            if r.status_code == 429:  # rate limited -> back off
                time.sleep(min(2 ** attempt * 2, 20))
                continue
            r.raise_for_status()
            return r.json()
        raise RuntimeError("OpenAQ rate limit: gave up after retries")

    def find_pm25_sensor(self, lat: float, lon: float, radius_m: int = 25000, max_age_h: int = 72,
                         now: datetime | None = None):
        data = self._get("/locations", {"coordinates": f"{lat},{lon}", "radius": radius_m,
                                        "parameters_id": PM25_PARAM_ID, "limit": 50})
        now = now or datetime.now().astimezone()
        cands = []
        for loc in data.get("results", []):
            sensors = [s for s in loc.get("sensors", [])
                       if (s.get("parameter") or {}).get("id") == PM25_PARAM_ID
                       or (s.get("parameter") or {}).get("name") == "pm25"]
            if not sensors:
                continue
            last = ((loc.get("datetimeLast") or {}).get("utc"))
            fresh = True
            if last:
                fresh = (now - parse(last)).total_seconds() <= max_age_h * 3600
            cands.append((0 if fresh else 1, loc.get("distance") or 0, loc, sensors[0]))
        if not cands:
            raise LookupError(f"no PM2.5 sensor within {radius_m} m of {lat},{lon}")
        cands.sort(key=lambda c: (c[0], c[1]))
        _, _, loc, sensor = cands[0]
        return int(sensor["id"]), loc.get("name") or f"location {loc.get('id')}"

    def hourly(self, sensor_id: int, start: datetime, end: datetime):
        """Hourly PM2.5 means -> list[(hour_end_utc, value)]."""
        out, page = [], 1
        while True:
            data = self._get(f"/sensors/{sensor_id}/hours",
                             {"datetime_from": iso(start), "datetime_to": iso(end), "limit": 1000, "page": page})
            res = data.get("results", [])
            for r in res:
                if r.get("value") is None:
                    continue
                per = r.get("period") or {}
                to = (per.get("datetimeTo") or {}).get("utc")
                frm = (per.get("datetimeFrom") or {}).get("utc")
                if to:
                    ts = parse(to)
                elif frm:
                    ts = parse(frm) + timedelta(hours=1)
                else:
                    continue
                out.append((floor_hour(ts), float(r["value"])))
            if len(res) < 1000:
                break
            page += 1
        return sorted(out)
