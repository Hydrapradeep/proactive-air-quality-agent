"""Learned anomaly / change-point detector.

Per station we *fit* (from the trailing 7 days, excluding the most recent hours):
  * a diurnal profile (24 shrunken hour-of-day offsets, in log-AQI space)
  * a robust baseline level (median of the de-seasonalised series)
  * a noise scale sigma (1.4826*MAD, floored)
Everything is then expressed as a z-score against *that station's own* normal, so a noisy dusty
city automatically gets a higher bar than a clean one. A one-sided CUSUM change-point statistic
runs over the z-scores; its threshold h is the "something has shifted" alarm.

Candidates (priority order): spike > trend > elevated > recovery.
Every check is returned (pass/fail + the numbers) so a decision can be audited later.
"""
from __future__ import annotations
import math
from dataclasses import dataclass, replace, asdict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import numpy as np

HOURS_FIT = 168      # history used to fit the model
RECENT_EXCL = 6      # most recent hours are excluded from the fit so an episode can't hide itself
GRID = 48            # hours of signal examined


@dataclass
class DetectorParams:
    spike_z: float = 3.25
    spike_confirm_frac: float = 0.75  # previous hour must ALSO be >= this * z threshold (kills 1-hour glitches)
    spike_sharp_ratio: float = 1.5    # now vs median of hours t-8..t-4
    trend_hours: int = 5
    trend_z: float = 2.0
    trend_min_rise_frac: float = 0.25
    trend_min_pos_frac: float = 0.75
    elevated_z: float = 2.5
    max_hour_jump: float = 2.2         # trend/elevated must not be a single-hour x2.2+ jump (that is a spike or a glitch)
    clear_z: float = 1.0
    clear_hours: int = 3
    recovery_drop_frac: float = 0.75  # now must be <= this * episode peak
    cusum_k: float = 0.75
    cusum_h: float = 6.0
    min_rise_abs: float = 12.0        # AQI points above expected-for-this-hour
    min_aqi: float = 30.0

    def scaled(self, sensitivity: float) -> "DetectorParams":
        s = max(0.3, float(sensitivity))
        return replace(self, spike_z=self.spike_z / s, trend_z=self.trend_z / s,
                       elevated_z=self.elevated_z / s, cusum_h=self.cusum_h / s)


@dataclass
class StationModel:
    base: float
    sigma: float
    diurnal: list
    n_fit: int

    def summary(self) -> dict:
        return {"baseline_aqi": round(math.expm1(self.base), 1), "sigma_log": round(self.sigma, 3),
                "n_fit": self.n_fit,
                "diurnal_range": round(max(self.diurnal) - min(self.diurnal), 3)}


@dataclass
class Signals:
    times: list
    aqi: np.ndarray
    z: np.ndarray
    expected: np.ndarray


@dataclass
class Candidate:
    kind: str | None
    onset: datetime | None
    checks: dict
    metrics: dict


def _lh(t: datetime, tz: ZoneInfo) -> int:
    return t.astimezone(tz).hour


def fit_model(times: list, aqi: list, tz: ZoneInfo, min_points: int = 48,
              sigma_floor: float = 0.12) -> StationModel | None:
    if len(aqi) < min_points:
        return None
    v = np.log1p(np.asarray(aqi, dtype=float))
    hrs = np.array([_lh(t, tz) for t in times])
    d = np.zeros(24)
    if len(v) >= 72:  # need a few days before trusting a diurnal shape
        level = np.median(v)
        for h in range(24):
            m = hrs == h
            n = int(m.sum())
            if n:
                d[h] = (np.median(v[m]) - level) * n / (n + 3.0)
    y = v - d[hrs]
    base = float(np.median(y))
    sigma = max(1.4826 * float(np.median(np.abs(y - base))), sigma_floor)
    return StationModel(base=base, sigma=sigma, diurnal=d.tolist(), n_fit=len(v))


def build_signals(model: StationModel, series: dict, now: datetime, tz: ZoneInfo) -> Signals:
    times = [now - timedelta(hours=GRID - 1 - i) for i in range(GRID)]
    aqi = np.array([series.get(t, np.nan) for t in times], dtype=float)
    d = np.array(model.diurnal)[[_lh(t, tz) for t in times]]
    with np.errstate(invalid="ignore"):
        z = (np.log1p(aqi) - d - model.base) / model.sigma
    expected = np.expm1(model.base + d)
    return Signals(times=times, aqi=aqi, z=z, expected=expected)


def cusum(z: np.ndarray, k: float, h: float):
    """One-sided upper CUSUM, capped at 2h so it forgets a long episode in bounded time."""
    S = np.zeros(len(z))
    s, run_start = 0.0, len(z)
    for i, zi in enumerate(z):
        if not np.isnan(zi):
            new = s + zi - k
            if new <= 0:
                s, run_start = 0.0, i + 1
            else:
                if s == 0.0:
                    run_start = i
                s = min(new, 2 * h)
        S[i] = s
    return S, run_start


def theil_sen(y: np.ndarray) -> float:
    idx = np.where(~np.isnan(y))[0]
    sl = [(y[j] - y[i]) / (j - i) for a, i in enumerate(idx) for j in idx[a + 1:]]
    return float(np.median(sl)) if sl else 0.0


def _f(x):
    x = float(x)
    return None if math.isnan(x) else round(x, 3)


def classify(sig: Signals, p: DetectorParams, in_episode: bool, episode_peak: float = 0.0) -> Candidate:
    z, a, exp = sig.z, sig.aqi, sig.expected
    n = len(z)
    zt = z[-1]
    if np.isnan(zt):
        return Candidate(None, None, {"reason": "no_reading_for_current_hour"}, {})
    zprev = z[-2]
    S, run_start = cusum(z, p.cusum_k, p.cusum_h)
    alarm = bool(S[-1] > p.cusum_h)
    onset = sig.times[run_start] if alarm and run_start < n else None
    rise_abs = float(a[-1] - exp[-1])
    guard = bool(rise_abs >= p.min_rise_abs and a[-1] >= p.min_aqi)

    # --- spike
    ref = a[-8:-3]
    ref = ref[~np.isnan(ref)]
    sharp_base = float(np.median(ref)) if len(ref) >= 3 else float("nan")
    sharp = float(a[-1] / sharp_base) if sharp_base and sharp_base > 0 else float("nan")
    sp = {"z_ok": bool(zt >= p.spike_z),
          "prev_hour_confirms": bool(zprev >= p.spike_z * p.spike_confirm_frac),
          "sharp_vs_recent": bool(sharp >= p.spike_sharp_ratio),
          "abs_guard": guard}

    # --- trend
    N = p.trend_hours
    w = a[-N:]
    pres = w[~np.isnan(w)]
    tr = {"enough_data": bool(len(pres) >= N - 1 and not np.isnan(w[-1]))}
    pos_frac = slope = rise = rise_frac = float("nan")
    if tr["enough_data"]:
        diffs = np.diff(pres)
        pos_frac = float(np.mean(diffs > 0))
        slope = theil_sen(w)
        rise = float(pres[-1] - pres[0])
        rise_frac = rise / max(float(pres[0]), 1.0)
    no_jump = bool(a[-1] <= p.max_hour_jump * max(a[-2], 1.0)) if not np.isnan(a[-2]) else False
    tr.update({"cusum_alarm": alarm, "z_ok": bool(zt >= p.trend_z),
               "prev_hour_confirms": bool(zprev >= p.trend_z * p.spike_confirm_frac),
               "no_single_hour_jump": no_jump,
               "mostly_rising": bool(pos_frac >= p.trend_min_pos_frac),
               "slope_positive": bool(slope > 0),
               "rise_big_enough": bool(rise_frac >= p.trend_min_rise_frac and rise >= p.min_rise_abs),
               "abs_guard": guard})

    # --- sustained elevation (level shift that is no longer rising / jumping)
    el = {"cusum_alarm": alarm, "z_ok": bool(zt >= p.elevated_z),
          "prev_hour_confirms": bool(zprev >= p.elevated_z * p.spike_confirm_frac),
          "no_single_hour_jump": no_jump, "abs_guard": guard}

    # --- recovery (only meaningful inside an alerted episode)
    zc = z[-p.clear_hours:]
    rc = {"in_alerted_episode": bool(in_episode),
          "z_clear_for_hours": bool(not np.isnan(zc).any() and (zc <= p.clear_z).all()),
          "dropped_from_peak": bool(episode_peak > 0 and a[-1] <= p.recovery_drop_frac * episode_peak)}

    metrics = {"aqi": _f(a[-1]), "expected_aqi": _f(exp[-1]), "z_now": _f(zt), "z_prev": _f(zprev),
               "rise_vs_expected": _f(rise_abs), "cusum": _f(S[-1]), "cusum_alarm": alarm,
               "sharp_ratio": _f(sharp), "trend_pos_frac": _f(pos_frac), "trend_slope": _f(slope),
               "trend_rise": _f(rise), "trend_rise_frac": _f(rise_frac),
               "onset": onset.isoformat() if onset else None}
    checks = {"spike": sp, "trend": tr, "elevated": el, "recovery": rc}

    kind = None
    if all(sp.values()):
        kind = "spike"
    elif all(tr.values()):
        kind = "trend"
    elif all(el.values()):
        kind = "elevated"
    elif all(rc.values()):
        kind = "recovery"
    return Candidate(kind, onset, checks, metrics)


def clean(o):
    """Make nested structures JSON-safe (nan -> None, numpy -> python)."""
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, (np.floating, float)):
        return None if math.isnan(float(o)) else round(float(o), 4)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    if isinstance(o, np.integer):
        return int(o)
    return o


def params_dict(p: DetectorParams) -> dict:
    return clean(asdict(p))
