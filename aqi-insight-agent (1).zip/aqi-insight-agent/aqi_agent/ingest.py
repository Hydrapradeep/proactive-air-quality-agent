"""Ingestion: pull new hourly readings per station and store them *with history*."""
from __future__ import annotations
from datetime import timedelta

from .aqi import pm25_to_aqi
from .db import jdump
from .util import iso, parse, utcnow

STUCK_RUN = 6  # >= this many identical consecutive hourly values => sensor considered stuck


def upsert_readings(conn, station_id: str, rows) -> int:
    now = iso(utcnow())
    n = 0
    for ts, pm in rows:
        valid = pm is not None and 0 <= pm <= 1000
        conn.execute("INSERT OR REPLACE INTO readings(station_id,ts,pm25,aqi,flag,ingested_at) VALUES(?,?,?,?,?,?)",
                     (station_id, iso(ts), pm, pm25_to_aqi(pm) if valid else None, "ok" if valid else "invalid", now))
        n += 1
    conn.commit()
    return n


def reflag_stuck(conn, station_id: str) -> int:
    """Causal run-length check: from the STUCK_RUN-th identical value onward, flag 'stuck'."""
    rows = conn.execute("SELECT ts,pm25,flag FROM readings WHERE station_id=? ORDER BY ts", (station_id,)).fetchall()
    run, prev, prev_ts, ups = 0, None, None, []
    for r in rows:
        if r["flag"] == "invalid":
            run, prev = 0, None
            continue
        ts = parse(r["ts"])
        if prev is not None and r["pm25"] == prev and prev_ts is not None and ts - prev_ts <= timedelta(hours=1):
            run += 1
        else:
            run = 1
        prev, prev_ts = r["pm25"], ts
        new = "stuck" if run >= STUCK_RUN else "ok"
        if new != r["flag"]:
            ups.append((new, station_id, r["ts"]))
    conn.executemany("UPDATE readings SET flag=? WHERE station_id=? AND ts=?", ups)
    conn.commit()
    return len(ups)


def ingest_station(conn, source, station, wall_now) -> int:
    sid = station["id"]
    try:
        if station["sensor_id"] is None:
            sensor_id, name = source.client.find_pm25_sensor(station["lat"], station["lon"], now=wall_now)
            conn.execute("UPDATE stations SET sensor_id=?, location_name=? WHERE id=?", (sensor_id, name, sid))
            conn.commit()
        else:
            sensor_id = station["sensor_id"]
        last = conn.execute("SELECT MAX(ts) m FROM readings WHERE station_id=?", (sid,)).fetchone()["m"]
        start = parse(last) - timedelta(hours=3) if last else wall_now - timedelta(days=7)
        rows = source.client.hourly(sensor_id, start, wall_now + timedelta(hours=1))
        n = upsert_readings(conn, sid, rows)
        reflag_stuck(conn, sid)
        conn.execute("INSERT INTO ingest_runs(ran_at,station_id,status,n_rows,detail) VALUES(?,?,?,?,?)",
                     (iso(utcnow()), sid, "ok", n, None))
        conn.commit()
        return n
    except Exception as e:  # keep going; the failure is visible in /api/ingest_runs
        conn.execute("INSERT INTO ingest_runs(ran_at,station_id,status,n_rows,detail) VALUES(?,?,?,?,?)",
                     (iso(utcnow()), sid, "error", 0, jdump(str(e))[:500]))
        conn.commit()
        return -1


class OpenAQSource:
    def __init__(self, api_key):
        from .openaq import OpenAQClient
        self.client = OpenAQClient(api_key)
