"""One hourly tick: ingest every station, then evaluate it."""
from __future__ import annotations
from datetime import timedelta

from .engine import evaluate_station
from .ingest import ingest_station
from .util import floor_hour, parse, utcnow


def make_source(settings):
    if settings.source == "openaq":
        from .ingest import OpenAQSource
        return OpenAQSource(settings.openaq_key)
    return None


def tick(conn, source, settings, wall_now=None, log=print):
    wall = floor_hour(wall_now or utcnow())
    results = {}
    for st in conn.execute("SELECT * FROM stations").fetchall():
        if source is not None:
            n = ingest_station(conn, source, st, wall)
            log(f"[ingest] {st['id']}: {'error' if n < 0 else f'{n} rows'}")
        last = conn.execute("SELECT MAX(ts) m FROM readings WHERE station_id=? AND flag='ok'", (st["id"],)).fetchone()["m"]
        now = parse(last) if last and wall - parse(last) <= timedelta(hours=3) else wall
        users = conn.execute("SELECT * FROM users WHERE station_id=?", (st["id"],)).fetchall()
        res = evaluate_station(conn, st, users, now, settings)
        results[st["id"]] = res
        for r in res:
            if r["action"] == "send":
                log(f"[notify] {r['user']}: {r['candidate']} ({r['reason']})")
    return results
