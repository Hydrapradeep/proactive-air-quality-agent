"""Glue: history -> fitted model -> candidate -> dedup policy -> message -> decision log."""
from __future__ import annotations
from datetime import timedelta
from zoneinfo import ZoneInfo

import numpy as np

from .aqi import band_of
from .db import jdump
from .detector import (HOURS_FIT, RECENT_EXCL, DetectorParams, build_signals, classify, clean, fit_model,
                       params_dict)
from .messages import build_context, generate
from .policy import PolicyConfig, UserState, decide
from .util import floor_hour, iso, parse, utcnow

STALE_H = 3


def _load_history(conn, station_id, now, days):
    rows = conn.execute(
        "SELECT ts, aqi FROM readings WHERE station_id=? AND flag='ok' AND ts<=? AND ts>=? ORDER BY ts",
        (station_id, iso(now), iso(now - timedelta(days=days)))).fetchall()
    return [(floor_hour(parse(r["ts"])), float(r["aqi"])) for r in rows]


def _log(conn, now, st, user, cand, action, reason, nid, det, win, before, after) -> int:
    cur = conn.execute(
        "INSERT INTO decisions(data_ts,evaluated_at,station_id,user_id,candidate,action,reason,notification_id,"
        "detector_json,window_json,state_before_json,state_after_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (iso(now), iso(utcnow()), st, user, cand, action, reason, nid, jdump(det), jdump(win), before, after))
    return cur.lastrowid


def evaluate_station(conn, station, users, now, settings=None, params: DetectorParams | None = None,
                     policy: PolicyConfig | None = None, use_llm: bool = True):
    """Evaluate one station at data-time `now` for each user. Returns list of decision dicts."""
    params, policy = params or DetectorParams(), policy or PolicyConfig()
    tz = ZoneInfo(station["tz"])
    hist30 = _load_history(conn, station["id"], now, 30)
    series = {t: v for t, v in hist30 if t >= now - timedelta(hours=HOURS_FIT)}
    latest = max(series) if series else None
    fit_pts = sorted((t, v) for t, v in series.items() if t <= now - timedelta(hours=RECENT_EXCL))
    model = fit_model([t for t, _ in fit_pts], [v for _, v in fit_pts], tz)
    out = []

    for u in users:
        st = UserState.from_json((conn.execute("SELECT state_json FROM user_state WHERE user_id=?",
                                               (u["id"],)).fetchone() or {"state_json": None})["state_json"])
        before = st.to_json()
        det, win, cand_kind, action, reason, nid = {}, [], None, "none", None, None
        new_state = st

        if latest is None or now - latest > timedelta(hours=STALE_H):
            reason = "stale_data"
            det = {"latest_reading": iso(latest) if latest else None}
        elif model is None:
            reason = "insufficient_history"
            det = {"points": len(fit_pts)}
        else:
            sig = build_signals(model, series, now, tz)
            p = params.scaled(u["sensitivity"])
            cand = classify(sig, p, st.status == "ELEVATED", st.episode_peak)
            cand_kind = cand.kind
            aqi_now = float(sig.aqi[-1]) if not np.isnan(sig.aqi[-1]) else float("nan")
            if cand.kind is None and cand.checks.get("reason"):
                reason = cand.checks["reason"]
                det = {"model": model.summary(), "checks": cand.checks}
            else:
                action, reason, new_state, info = decide(st, cand.kind, aqi_now, now, policy)
                det = clean({"model": model.summary(), "params": params_dict(p), "sensitivity": u["sensitivity"],
                             "metrics": cand.metrics, "checks": cand.checks, "policy": info})
                win = clean([{"ts": iso(t), "aqi": a, "z": z, "expected": e}
                             for t, a, z, e in zip(sig.times[-24:], sig.aqi[-24:], sig.z[-24:], sig.expected[-24:])])
                if action == "send":
                    peak_ts = None
                    if cand.kind == "recovery":
                        w = [(t, a) for t, a in zip(sig.times, sig.aqi) if not np.isnan(a)]
                        peak_ts = max(w, key=lambda x: x[1])[0] if w else None
                    prev = [dict(r) for r in conn.execute(
                        "SELECT ts,kind,aqi FROM notifications WHERE user_id=? ORDER BY ts DESC LIMIT 3", (u["id"],))]
                    ep_start = parse(st.episode_start) if st.episode_start else now
                    ctx = build_context(
                        kind=cand.kind, reason=reason, city=station["name"], user=u, now=now, tz=tz, aqi=aqi_now,
                        expected=float(sig.expected[-1]), onset=cand.onset,
                        trend_start_aqi=float(sig.aqi[-5]) if cand.kind == "trend" and not np.isnan(sig.aqi[-5]) else None,
                        episode_peak=st.episode_peak, episode_peak_ts=peak_ts,
                        history=[(t, v) for t, v in hist30 if t < now - timedelta(hours=12)] or hist30,
                        prev_notifs=prev, hours_in_episode=int((now - ep_start).total_seconds() // 3600))
                    msg, src = generate(ctx, settings if use_llm else None)
                    cur = conn.execute(
                        "INSERT INTO notifications(ts,user_id,station_id,kind,band,aqi,message,message_source,"
                        "decision_id,context_json) VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (iso(now), u["id"], station["id"], cand.kind, band_of(aqi_now), int(round(aqi_now)), msg,
                         src, None, jdump(ctx)))
                    nid = cur.lastrowid

        after = new_state.to_json()
        did = _log(conn, now, station["id"], u["id"], cand_kind, action, reason, nid, det, win, before, after)
        if nid:
            conn.execute("UPDATE notifications SET decision_id=? WHERE id=?", (did, nid))
        conn.execute("INSERT INTO user_state(user_id,state_json,updated_at) VALUES(?,?,?) "
                     "ON CONFLICT(user_id) DO UPDATE SET state_json=excluded.state_json, updated_at=excluded.updated_at",
                     (u["id"], after, iso(utcnow())))
        out.append({"user": u["id"], "candidate": cand_kind, "action": action, "reason": reason, "decision_id": did})
    conn.commit()
    return out
