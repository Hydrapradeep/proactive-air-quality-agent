"""Offline simulator with *ground truth*, used for the demo and the evaluation harness.

Generates hourly PM2.5 with diurnal cycle + AR(1) noise + daily drift, then injects labelled events:
  spike   - sudden multiplicative jump that decays            (positive)
  trend   - ~6h ramp, short plateau, then decay                (positive)
  glitch  - single-hour sensor spike                           (negative: must NOT alert)
  stuck   - sensor repeats one value for 8h                    (negative: must NOT alert)
plus random missing hours. Each positive event also implies a "recovery" moment when it ends.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import numpy as np


@dataclass
class TruthEvent:
    kind: str
    start: datetime
    end: datetime
    ramp_end: datetime | None = None
    peak_mult: float = 1.0


def generate_series(city: dict, start: datetime, hours: int, seed: int, burn_in_h: int = 216,
                    gaps: bool = True):
    rng = np.random.default_rng(seed)
    sim = city["sim"]
    tz = ZoneInfo(city["tz"])
    times = [start + timedelta(hours=i) for i in range(hours)]
    lh = np.array([t.astimezone(tz).hour for t in times])
    diurnal = sim["amp"] * (0.7 * np.cos(2 * np.pi * (lh - 23) / 24) + 0.3 * np.cos(2 * np.pi * (lh - 8) / 12))
    phi, sd = 0.88, sim["noise"]
    e = np.zeros(hours)
    for i in range(1, hours):
        e[i] = phi * e[i - 1] + sd * math.sqrt(1 - phi ** 2) * rng.normal()
    days = np.repeat(rng.normal(0, 0.5 * sd, hours // 24 + 2), 24)[:hours]
    pm = np.exp(math.log(sim["mean"]) + diurnal + e + days)

    mult = np.ones(hours)
    events: list[TruthEvent] = []
    stuck_spans = []
    cur = burn_in_h + int(rng.integers(8, 24))
    while cur < hours - 30:
        kind = rng.choice(["spike", "trend", "spike", "trend", "glitch", "stuck"])
        if kind == "spike":
            M, tau = rng.uniform(2.8, 4.5), rng.uniform(3, 6)
            t1 = cur + int(math.ceil(tau * math.log((M - 1) / 0.2)))
            for i in range(cur, min(t1 + 6, hours)):
                mult[i] *= 1 + (M - 1) * math.exp(-(i - cur) / tau)
            events.append(TruthEvent("spike", times[cur], times[min(t1, hours - 1)], None, M))
        elif kind == "trend":
            R, M, H, D = int(rng.integers(5, 9)), rng.uniform(2.2, 3.2), int(rng.integers(3, 7)), 4
            for j in range(R):
                mult[cur + j] *= math.exp(math.log(M) * (j + 1) / R)
            for j in range(H):
                mult[cur + R + j] *= M
            for j in range(D):
                mult[cur + R + H + j] *= math.exp(math.log(M) * (1 - (j + 1) / D))
            t1 = cur + R + H + D
            events.append(TruthEvent("trend", times[cur], times[min(t1, hours - 1)], times[cur + R], M))
        elif kind == "glitch":
            mult[cur] *= rng.uniform(6, 12)
            events.append(TruthEvent("glitch", times[cur], times[cur], None, 8))
        else:
            stuck_spans.append((cur, cur + 8))
            events.append(TruthEvent("stuck", times[cur], times[min(cur + 8, hours - 1)]))
        cur += int(rng.integers(40, 75))
    pm = np.round(pm * mult, 1)
    for a, b in stuck_spans:
        pm[a:b] = pm[a]
    keep = np.ones(hours, dtype=bool)
    if gaps:
        for _ in range(max(1, hours // 24 // 4)):
            g = int(rng.integers(burn_in_h // 2, hours - 6))
            keep[g:g + int(rng.integers(2, 5))] = False
    rows = [(times[i], float(pm[i])) for i in range(hours) if keep[i]]
    return rows, events
