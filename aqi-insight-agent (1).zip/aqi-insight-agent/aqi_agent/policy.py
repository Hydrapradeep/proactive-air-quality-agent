"""Dedup / rate-limiting state machine.

Per user we remember what we've already said. A candidate becomes a notification only if it is a
*meaningful change* relative to that memory:

  NORMAL   + worsening candidate -> send (new episode) unless inside the post-alert cooldown
  ELEVATED + band goes up         -> send ("band_escalation"), min 1h gap
  ELEVATED + >=35% & >=30 pts up  -> send ("major_worsening") only if cooldown has elapsed
  ELEVATED + anything else        -> suppress (duplicate)
  ELEVATED + recovery             -> send once, close the episode

Cooldown decays/backs-off: base 3h, doubling with each alert in a streak (3h, 6h, 12h, 24h cap).
The streak counter decays by 1 per 12h of silence so a calm day resets the nagging penalty.
"""
from __future__ import annotations
import json
from dataclasses import dataclass, asdict, replace
from datetime import timedelta

from .aqi import band_of
from .util import iso, parse


@dataclass
class PolicyConfig:
    base_cooldown_h: float = 3.0
    max_cooldown_h: float = 24.0
    decay_h: float = 12.0
    min_gap_escalation_h: float = 1.0
    worsen_ratio: float = 1.35
    worsen_abs: float = 30.0
    episode_expiry_h: float = 36.0


@dataclass
class UserState:
    status: str = "NORMAL"            # NORMAL | ELEVATED
    episode_id: int = 0
    episode_start: str | None = None
    episode_peak: float = 0.0
    episode_alerts: int = 0
    last_alert_kind: str | None = None
    last_alert_band: int = -1
    last_alert_aqi: float = 0.0
    last_alert_ts: str | None = None
    repeat_count: int = 0
    cooldown_until: str | None = None
    last_recovery_ts: str | None = None
    last_candidate_ts: str | None = None

    @classmethod
    def from_json(cls, s: str | None) -> "UserState":
        return cls(**json.loads(s)) if s else cls()

    def to_json(self) -> str:
        return json.dumps(asdict(self))


def _send(s: UserState, kind: str, aqi: float, now, eff_repeat: int, cfg: PolicyConfig, new_episode: bool):
    nowi = iso(now)
    s.repeat_count = eff_repeat + 1
    cd = min(cfg.max_cooldown_h, cfg.base_cooldown_h * 2 ** (s.repeat_count - 1))
    s.cooldown_until = iso(now + timedelta(hours=cd))
    s.last_alert_kind, s.last_alert_band = kind, band_of(aqi)
    s.last_alert_aqi, s.last_alert_ts, s.last_candidate_ts = float(aqi), nowi, nowi
    if new_episode:
        s.status, s.episode_id, s.episode_start = "ELEVATED", s.episode_id + 1, nowi
        s.episode_alerts, s.episode_peak = 1, float(aqi)
    else:
        s.episode_alerts += 1
        s.episode_peak = max(s.episode_peak, float(aqi))
    return cd


def decide(state: UserState, kind: str | None, aqi: float, now, cfg: PolicyConfig = PolicyConfig()):
    """Returns (action, reason, new_state, info). action in {send, suppress, none}."""
    s = replace(state)
    nowi = iso(now)
    last = parse(s.last_alert_ts) if s.last_alert_ts else None
    cool = parse(s.cooldown_until) if s.cooldown_until else None
    eff_repeat = s.repeat_count
    if last:
        eff_repeat = max(0, s.repeat_count - int((now - last).total_seconds() // 3600 // cfg.decay_h))
    info = {"streak_effective": eff_repeat, "cooldown_until": s.cooldown_until,
            "hours_since_last_alert": round((now - last).total_seconds() / 3600, 1) if last else None}

    if kind is None:
        if s.status == "ELEVATED" and s.last_candidate_ts and \
                now - parse(s.last_candidate_ts) > timedelta(hours=cfg.episode_expiry_h):
            s.status = "NORMAL"
            return "none", "episode_expired_silently", s, info
        return "none", "no_candidate", s, info

    if kind == "recovery":
        s.status, s.last_recovery_ts = "NORMAL", nowi
        return "send", "recovery_after_alerted_episode", s, info

    band = band_of(aqi)
    if s.status == "ELEVATED":
        s.episode_peak = max(s.episode_peak, float(aqi))
        s.last_candidate_ts = nowi
        gap_h = (now - last).total_seconds() / 3600 if last else 99
        if band > s.last_alert_band:
            if gap_h >= cfg.min_gap_escalation_h:
                _send(s, kind, aqi, now, eff_repeat, cfg, False)
                return "send", "band_escalation", s, info
            return "suppress", "escalation_within_min_gap", s, info
        if aqi >= s.last_alert_aqi * cfg.worsen_ratio and aqi - s.last_alert_aqi >= cfg.worsen_abs:
            if cool is None or now >= cool:
                _send(s, kind, aqi, now, eff_repeat, cfg, False)
                return "send", "major_worsening", s, info
            return "suppress", "worsening_but_in_cooldown", s, info
        return "suppress", "duplicate_ongoing_episode", s, info

    # NORMAL
    if cool and now < cool and band <= s.last_alert_band:
        return "suppress", "flap_cooldown_recent_alert", s, info
    _send(s, kind, aqi, now, eff_repeat, cfg, True)
    return "send", "new_episode", s, info
