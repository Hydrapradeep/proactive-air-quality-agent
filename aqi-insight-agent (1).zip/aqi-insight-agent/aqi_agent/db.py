from __future__ import annotations
import json
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS stations (
  id TEXT PRIMARY KEY, name TEXT, lat REAL, lon REAL, tz TEXT,
  sensor_id INTEGER, location_name TEXT);
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY, name TEXT, station_id TEXT, sensitivity REAL, activity TEXT);
-- history, not just latest: one row per station-hour
CREATE TABLE IF NOT EXISTS readings (
  station_id TEXT, ts TEXT, pm25 REAL, aqi INTEGER,
  flag TEXT DEFAULT 'ok',            -- ok | invalid | stuck
  ingested_at TEXT, PRIMARY KEY (station_id, ts));
CREATE TABLE IF NOT EXISTS ingest_runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ran_at TEXT, station_id TEXT,
  status TEXT, n_rows INTEGER, detail TEXT);
-- dedup memory: one JSON blob per user (see policy.UserState)
CREATE TABLE IF NOT EXISTS user_state (
  user_id TEXT PRIMARY KEY, state_json TEXT NOT NULL, updated_at TEXT);
-- one row for EVERY evaluation, fired or not: the debugging trail
CREATE TABLE IF NOT EXISTS decisions (
  id INTEGER PRIMARY KEY AUTOINCREMENT, data_ts TEXT, evaluated_at TEXT,
  station_id TEXT, user_id TEXT, candidate TEXT, action TEXT, reason TEXT,
  notification_id INTEGER, detector_json TEXT, window_json TEXT,
  state_before_json TEXT, state_after_json TEXT);
CREATE TABLE IF NOT EXISTS notifications (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, user_id TEXT, station_id TEXT,
  kind TEXT, band INTEGER, aqi INTEGER, message TEXT, message_source TEXT,
  decision_id INTEGER, context_json TEXT);
CREATE INDEX IF NOT EXISTS ix_dec_ts ON decisions(data_ts);
CREATE INDEX IF NOT EXISTS ix_dec_user ON decisions(user_id, data_ts);
CREATE INDEX IF NOT EXISTS ix_notif_user ON notifications(user_id, ts);
"""


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def seed_config(conn: sqlite3.Connection, cities, users) -> None:
    for c in cities:
        conn.execute(
            "INSERT INTO stations(id,name,lat,lon,tz) VALUES(?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, lat=excluded.lat, lon=excluded.lon, tz=excluded.tz",
            (c["id"], c["name"], c["lat"], c["lon"], c["tz"]))
    for u in users:
        conn.execute(
            "INSERT INTO users(id,name,station_id,sensitivity,activity) VALUES(?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, station_id=excluded.station_id, "
            "sensitivity=excluded.sensitivity, activity=excluded.activity",
            (u["id"], u["name"], u["station"], u["sensitivity"], u["activity"]))
    conn.commit()


def jdump(obj) -> str:
    return json.dumps(obj, default=str, separators=(",", ":"))
