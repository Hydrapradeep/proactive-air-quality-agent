"""Turn a fired insight into a short, human notification.

Each message = headline (what changed) + past context (history / previous alert) + ONE next action.
If ANTHROPIC_API_KEY is set an LLM rewrites it from the structured context; otherwise (or on any
failure / bad output) a deterministic template is used, so a notification is never lost.
"""
from __future__ import annotations
import hashlib
import json
from datetime import timedelta
from zoneinfo import ZoneInfo

from .aqi import BAND_NAMES, band_of
from .util import parse

ACTIONS = {
    "runner": {
        "hi": ["Skip the outdoor run today; a treadmill session is the safer swap.",
               "Move today's run indoors or take a rest day."],
        "mid": ["Consider moving your run indoors, or keep it short and easy.",
                "If you run, keep it light and shorter than usual."],
        "lo": ["Still fine to run, but stick to quieter routes away from traffic.",
               "Fine for a run; a park beats a main road right now."],
        "rec": ["Good window to get that run in.", "Good time to head out for a run."],
    },
    "cyclist": {
        "hi": ["Take transit instead of cycling today, or wear a fitted N95 if you have to ride.",
               "Leave the bike at home today; transit is the safer commute."],
        "mid": ["If you cycle, take quieter back streets and consider a mask.",
                "Consider a mask for the ride, and avoid the busy roads."],
        "lo": ["Cycling is fine, but quieter streets will keep your exposure down.",
               "Fine to ride; pick the low-traffic route."],
        "rec": ["Good time to get back on the bike.", "Fine to cycle again."],
    },
    "parent": {
        "hi": ["Keep the kids' playtime indoors until it eases.",
               "Hold off on outdoor play and keep windows shut for now."],
        "mid": ["Keep outdoor play short and windows closed for now.",
                "Shorten outdoor play and keep an eye on it."],
        "lo": ["Outdoor play is fine, just pick a park away from main roads.",
               "Fine for outdoor play, but keep it shorter than usual."],
        "rec": ["Good time to open the windows and head back to the park.",
                "Fine to take the kids out again."],
    },
    "commuter": {
        "hi": ["Wear a fitted N95 for the commute and run your purifier on high at home.",
               "Mask up (N95) for the commute and keep windows shut."],
        "mid": ["Keep windows closed and consider a mask for the commute.",
                "Close the windows and consider a mask when you head out."],
        "lo": ["Worth keeping windows closed for the next few hours.",
               "Keep windows shut for a few hours."],
        "rec": ["Good time to air the house out.", "Open the windows and let fresh air in."],
    },
}

SYSTEM_PROMPT = (
    "You write one push notification for an air-quality app. Rules: at most 2 short sentences "
    "(<= 240 characters), natural and conversational, no emojis, no raw JSON, not just 'AQI is X'. "
    "Reference the relevant past context provided (e.g. earlier alert, how unusual it is, when it "
    "started). Include exactly one clear next action, based on `suggested_action` (reword it freely). "
    "No medical diagnoses. Output only the notification text."
)


def _pick(options, key: str):
    h = int(hashlib.md5(key.encode()).hexdigest(), 16)
    return options[h % len(options)]


def _hr(lt) -> str:
    if lt.hour == 0:
        return "midnight"
    if lt.hour == 12:
        return "noon"
    return f"{lt.hour % 12} {'AM' if lt.hour < 12 else 'PM'}"


def _daypart(h: int) -> str:
    return "morning" if 5 <= h < 12 else "afternoon" if 12 <= h < 17 else "evening" if 17 <= h < 21 else "night"


def since_phrase(t, now, tz) -> str:
    lt, ln = t.astimezone(tz), now.astimezone(tz)
    days = (ln.date() - lt.date()).days
    if days == 0:
        return f"since {_hr(lt)}"
    if days == 1:
        dp = _daypart(lt.hour)
        return "since last night" if dp == "night" else f"since yesterday {dp}"
    return f"since {lt:%A}"


def ref_phrase(t, now, tz) -> str:
    lt, ln = t.astimezone(tz), now.astimezone(tz)
    days = (ln.date() - lt.date()).days
    dp = _daypart(lt.hour)
    if days == 0:
        return "overnight" if dp == "night" else f"this {dp}"
    if days == 1:
        return "last night" if dp == "night" else f"yesterday {dp}"
    if days < 7:
        return f"on {lt:%A}"
    return f"on {lt:%b} {lt.day}"


def ratio_phrase(aqi: float, expected: float) -> str:
    if not expected or expected <= 0:
        return ""
    r = aqi / expected
    if r >= 1.8:
        return f"about {r:.1f}x the usual for this hour"
    return f"roughly {round((r - 1) * 100)}% above the usual for this hour"


def build_context(*, kind, reason, city, user, now, tz, aqi, expected, onset, trend_start_aqi,
                  episode_peak, episode_peak_ts, history, prev_notifs, hours_in_episode) -> dict:
    """history: list[(datetime, aqi)] (up to ~30 days); prev_notifs: newest first dicts."""
    band = band_of(aqi)
    ctx = {"kind": kind, "reason": reason, "city": city, "user": user["name"], "activity": user["activity"],
           "aqi": int(round(aqi)), "band": BAND_NAMES[band],
           "vs_usual": ratio_phrase(aqi, expected), "usual_aqi_for_this_hour": int(round(expected))}
    if onset is not None:
        ctx["since"] = since_phrase(onset, now, tz)
    if trend_start_aqi is not None:
        ctx["trend_from_aqi"] = int(round(trend_start_aqi))
    # past context 1: previous notification to this user
    if prev_notifs:
        p = prev_notifs[0]
        pt = parse(p["ts"])
        if now - pt <= timedelta(hours=72):
            ctx["previous_alert"] = {"kind": p["kind"], "aqi": p["aqi"], "when": ref_phrase(pt, now, tz),
                                     "same_episode": bool(reason in ("band_escalation", "major_worsening"))}
    # past context 2: how extreme versus what we've tracked
    if history:
        span_days = (now - history[0][0]).total_seconds() / 86400
        cutoff = now - timedelta(hours=12)
        higher = [t for t, v in history if t < cutoff and v >= aqi]
        if higher:
            last_t = max(higher)
            if (now - last_t) > timedelta(hours=36):
                ctx["highest_since"] = ref_phrase(last_t, now, tz)
        elif span_days >= 3 and kind != "recovery":
            ctx["highest_since"] = f"anything in the {int(span_days)} days we've tracked"
    if kind == "recovery":
        ctx["episode_peak_aqi"] = int(round(episode_peak))
        if episode_peak_ts is not None:
            ctx["peak_when"] = ref_phrase(episode_peak_ts, now, tz)
        ctx["hours_in_episode"] = hours_in_episode
    level = "rec" if kind == "recovery" else "hi" if band >= 3 else "mid" if band == 2 else "lo"
    acts = ACTIONS.get(user["activity"], ACTIONS["commuter"])[level]
    ctx["suggested_action"] = _pick(acts, f"{user['name']}{now.isoformat()}")
    return ctx


def template_message(ctx: dict) -> str:
    c, k = ctx["city"], ctx["kind"]
    key = f"{ctx['user']}{ctx['aqi']}{k}"
    if k == "spike":
        head = _pick([f"Air in {c} just jumped: AQI {ctx['aqi']}, {ctx['vs_usual']}.",
                      f"{c}'s air quality spiked sharply to AQI {ctx['aqi']} ({ctx['vs_usual']})."], key)
    elif k == "trend":
        frm = f" (AQI {ctx['trend_from_aqi']} to {ctx['aqi']})" if "trend_from_aqi" in ctx else ""
        head = _pick([f"Air in {c} has been getting steadily worse over the last few hours{frm}.",
                      f"{c}'s air has been climbing for the past several hours{frm}."], key)
    elif k == "elevated":
        head = f"Air in {c} is running well above normal {ctx.get('since', '')}: AQI {ctx['aqi']}, {ctx['vs_usual']}.".replace(" :", ":")
    else:
        pk = f"{ctx['episode_peak_aqi']}"
        when = f" {ctx['peak_when']}" if ctx.get("peak_when") else ""
        head = f"Air in {c} has cleared up: AQI {ctx['aqi']}, down from a peak of {pk}{when}."
    extra = ""
    pa = ctx.get("previous_alert")
    if k != "recovery":
        if pa and pa.get("same_episode"):
            extra = f"That's worse than the AQI {pa['aqi']} I flagged {pa['when']}."
        elif ctx.get("highest_since"):
            hs = ctx["highest_since"]
            extra = f"It's the highest reading since {hs[3:] if hs.startswith('on ') else hs}." if not hs.startswith("anything") \
                else f"It's the highest in the {hs.split('the ', 1)[1]}."
        elif pa:
            extra = f"Similar to the AQI {pa['aqi']} I flagged {pa['when']}."
    elif ctx.get("hours_in_episode"):
        extra = f"It was elevated for about {ctx['hours_in_episode']} hours."
    return " ".join(x for x in (head, extra, ctx["suggested_action"]) if x)


def llm_message(ctx: dict, api_key: str, model: str) -> str | None:
    try:
        import httpx
        r = httpx.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": model, "max_tokens": 200, "system": SYSTEM_PROMPT,
                  "messages": [{"role": "user", "content": json.dumps(ctx)}]},
            timeout=15)
        r.raise_for_status()
        text = "".join(b.get("text", "") for b in r.json().get("content", []) if b.get("type") == "text").strip()
        if 20 <= len(text) <= 320 and "{" not in text:
            return text
    except Exception:
        return None
    return None


def generate(ctx: dict, settings=None) -> tuple[str, str]:
    """Returns (message, source) where source is 'llm' or 'template'."""
    if settings is not None and getattr(settings, "anthropic_key", None):
        m = llm_message(ctx, settings.anthropic_key, settings.llm_model)
        if m:
            return m, "llm"
    return template_message(ctx), "template"
