import httpx
from datetime import datetime, timezone
from aqi_agent.openaq import OpenAQClient


def handler(request: httpx.Request) -> httpx.Response:
    assert request.headers["X-API-Key"] == "k"
    if request.url.path.endswith("/locations"):
        return httpx.Response(200, json={"results": [
            {"id": 1, "name": "Far stale", "distance": 20000, "datetimeLast": {"utc": "2020-01-01T00:00:00Z"},
             "sensors": [{"id": 11, "parameter": {"id": 2, "name": "pm25"}}]},
            {"id": 2, "name": "Near fresh", "distance": 900, "datetimeLast": {"utc": "2026-10-10T05:00:00Z"},
             "sensors": [{"id": 22, "parameter": {"id": 7, "name": "no2"}}, {"id": 23, "parameter": {"id": 2, "name": "pm25"}}]}]})
    return httpx.Response(200, json={"results": [
        {"value": 41.2, "period": {"datetimeFrom": {"utc": "2026-10-10T03:00:00Z"}, "datetimeTo": {"utc": "2026-10-10T04:00:00Z"}}},
        {"value": None, "period": {"datetimeTo": {"utc": "2026-10-10T05:00:00Z"}}}]})


def test_find_sensor_and_hours():
    c = OpenAQClient("k", transport=httpx.MockTransport(handler))
    now = datetime(2026, 10, 10, 6, tzinfo=timezone.utc)
    assert c.find_pm25_sensor(28.6, 77.2, now=now) == (23, "Near fresh")
    rows = c.hourly(23, now, now)
    assert len(rows) == 1 and rows[0][1] == 41.2 and rows[0][0].hour == 4
