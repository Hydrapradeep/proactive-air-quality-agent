from datetime import timedelta
import numpy as np
from zoneinfo import ZoneInfo

from aqi_agent.aqi import pm25_to_aqi, band_of
from aqi_agent.config import CITIES, USERS
from aqi_agent.db import connect, seed_config
from aqi_agent.detector import DetectorParams, build_signals, classify, fit_model
from aqi_agent.engine import evaluate_station
from aqi_agent.ingest import reflag_stuck, upsert_readings
from aqi_agent.policy import UserState, decide
from aqi_agent.util import parse

T0 = parse("2026-09-01T00:00:00Z")
UTC = ZoneInfo("UTC")


def test_aqi_breakpoints():
    assert pm25_to_aqi(0) == 0 and pm25_to_aqi(9.0) == 50
    assert pm25_to_aqi(35.4) == 100 and pm25_to_aqi(55.4) == 150
    assert pm25_to_aqi(12.0) == 56
    assert band_of(50) == 0 and band_of(51) == 1 and band_of(301) == 5


def _flat_series(hours=200, level=20.0, seed=0):
    rng = np.random.default_rng(seed)
    return [(T0 + timedelta(hours=i), float(np.round(level * np.exp(rng.normal(0, 0.08)), 1))) for i in range(hours)]


def _run(extra, cities=None):
    """Replay a flat 8-day series + `extra` (hour offset -> pm25 override) through the engine for one user."""
    c = next(x for x in CITIES if x["id"] == "london")
    conn = connect(":memory:")
    seed_config(conn, [c], [u for u in USERS if u["station"] == "london"])
    rows = _flat_series()
    for h, v in extra.items():
        rows[h] = (rows[h][0], v)
    upsert_readings(conn, "london", rows); reflag_stuck(conn, "london")
    st = conn.execute("SELECT * FROM stations").fetchone()
    us = conn.execute("SELECT * FROM users").fetchall()
    for h in range(168, len(rows)):
        evaluate_station(conn, st, us, rows[h][0], None, use_llm=False)
    return conn


def test_single_hour_glitch_does_not_fire():
    conn = _run({180: 400.0})
    assert conn.execute("SELECT COUNT(*) FROM notifications").fetchone()[0] == 0


def test_plateau_sends_once_then_recovery():
    # sustained jump from hour 180 for 8 hours: exactly one alert + one recovery, not 8 alerts
    conn = _run({h: 120.0 + (h % 3) for h in range(180, 188)})
    kinds = [r["kind"] for r in conn.execute("SELECT kind FROM notifications ORDER BY ts")]
    assert kinds.count("recovery") == 1 and len(kinds) == 2, kinds
    suppressed = conn.execute("SELECT COUNT(*) FROM decisions WHERE action='suppress'").fetchone()[0]
    assert suppressed >= 3
    # every evaluation is logged (32 hours x 1 user), fired or not
    assert conn.execute("SELECT COUNT(*) FROM decisions").fetchone()[0] == 32


def test_stuck_sensor_is_quarantined():
    conn = connect(":memory:")
    seed_config(conn, CITIES[:1], [])
    upsert_readings(conn, "delhi", [(T0 + timedelta(hours=i), 50.0) for i in range(10)])
    reflag_stuck(conn, "delhi")
    flags = [r["flag"] for r in conn.execute("SELECT flag FROM readings ORDER BY ts")]
    assert flags[:5] == ["ok"] * 5 and flags[5:] == ["stuck"] * 5


def test_policy_escalation_and_cooldown():
    now = T0
    s = UserState()
    a, r, s, _ = decide(s, "spike", 120, now)
    assert (a, r) == ("send", "new_episode")
    a, r, s, _ = decide(s, "elevated", 125, now + timedelta(hours=1))
    assert a == "suppress"                                   # same band, no material change
    a, r, s, _ = decide(s, "spike", 160, now + timedelta(hours=2))
    assert (a, r) == ("send", "band_escalation")             # band 2 -> 3
    a, r, s, _ = decide(s, "recovery", 70, now + timedelta(hours=4))
    assert a == "send" and s.status == "NORMAL"
    a, r, s, _ = decide(s, "spike", 120, now + timedelta(hours=5))
    assert (a, r) == ("suppress", "flap_cooldown_recent_alert")   # re-trigger inside cooldown, not worse


def test_sensitivity_lowers_the_bar():
    p = DetectorParams()
    assert p.scaled(1.5).spike_z < p.spike_z < p.scaled(0.7).spike_z


def test_per_station_baseline_is_learned():
    tz = UTC
    clean = _flat_series(200, 20.0)
    rng = np.random.default_rng(1)
    noisy = [(t, float(np.round(20 * np.exp(rng.normal(0, 0.4)), 1))) for t, _ in clean]
    m1 = fit_model([t for t, _ in clean], [v for _, v in clean], tz)
    m2 = fit_model([t for t, _ in noisy], [v for _, v in noisy], tz)
    assert m2.sigma > 2 * m1.sigma   # noisy/dusty station => higher bar
