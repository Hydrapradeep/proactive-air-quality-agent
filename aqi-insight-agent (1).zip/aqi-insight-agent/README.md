# Proactive Air Quality Insight Agent

A backend service that watches hourly PM2.5 from [OpenAQ](https://openaq.org) for 5 cities and decides, on its own,
when a user is worth interrupting, with a short, human message and one concrete next action.

```
OpenAQ v3 ──hourly──▶ ingest ──▶ readings (history, quality flags)
                                     │
                       fit per-station model (baseline, diurnal, noise σ)
                                     │
                    z-scores + CUSUM change-point ──▶ candidate: spike | trend | elevated | recovery
                                     │                        (user sensitivity scales the thresholds)
                          dedup / cooldown state machine (per user)  ──▶ send | suppress | none
                                     │
                      message builder (LLM if key set, template fallback)
                                     │
        decisions (EVERY evaluation, with inputs + checks)  +  notifications  ──▶ /api/* and dashboard
```

## Quick start

```bash
pip install -r requirements.txt
python -m pytest -q                       # 8 tests

# 1. Offline demo (no network/keys): replays 28 simulated days through the full pipeline
python -m aqi_agent demo                  # -> demo.db, docs/NOTIFICATION_HISTORY.md, docs/EVAL_REPORT.md
AQI_DB=demo.db AQI_SCHEDULER=off AQI_SOURCE=none python -m aqi_agent serve   # browse http://127.0.0.1:8000

# 2. Live against OpenAQ (free key: https://explore.openaq.org/register)
export OPENAQ_API_KEY=...                 # optional: ANTHROPIC_API_KEY for LLM-written messages
python -m aqi_agent check-openaq          # resolves a PM2.5 sensor per city, prints recent rows
python -m aqi_agent serve                 # hourly job at HH:05 + immediate backfill of 7 days
```

Other commands: `python -m aqi_agent tick` (one ingest+evaluate pass), `python -m aqi_agent eval --source sim|db`.

## Endpoints (observability)

| Endpoint | What it shows |
|---|---|
| `/` | dashboard: sparkline per city with alert markers, notification list, recent candidate decisions, per-user memory |
| `/api/decisions?station_id=&user_id=&action=&candidate_only=` | one row per evaluation (fired, suppressed or nothing) |
| `/api/decisions/{id}` | full trace: fitted model, thresholds used, every check pass/fail with numbers, last 24h window with z-scores, policy state before/after, the notification + its message context |
| `/api/notifications` | notification history |
| `/api/state` | the dedup memory per user |
| `/api/readings/{station}`, `/api/ingest_runs`, `/api/stations`, `POST /api/tick` | data and ingestion health |

"Why didn't I get a nudge?" → find the decision for that hour: `reason` is one of `no_candidate`, `stale_data`,
`insufficient_history`, `duplicate_ongoing_episode`, `flap_cooldown_recent_alert`, `worsening_but_in_cooldown`, …
and `checks` shows which detector condition failed.

## Layout

`aqi_agent/` detector.py (model) · policy.py (dedup state machine) · engine.py (glue + logging) · messages.py ·
ingest.py / openaq.py · simulator.py + evaluate.py (replay harness) · app.py (API) · `docs/DECISIONS.md` (architecture note)

## Honest limitations

* **OpenAQ was not reachable from the sandbox this was built in.** The client follows the documented v3 shapes and is tested
  against a mocked transport only; the offline demo/eval use a *simulator with ground truth*. Run `check-openaq` first and
  tell me if a field name differs. Everything downstream of ingestion is source-independent.
* Detector thresholds were tuned on the simulator. Treat the eval numbers as a regression harness, not proof of
  real-world accuracy; `python -m aqi_agent eval --source db` replays your stored real history with model-free heuristic labels.
* Natural excursions in noisy series are scored as false positives in the simulated eval even though a user might want them.

## Video
`python -m scripts.make_video` renders a captioned demo video (demo_video.mp4) from demo.db (needs Pillow + ffmpeg).
