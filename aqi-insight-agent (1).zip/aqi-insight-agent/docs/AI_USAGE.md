# AI tools used

This project was built in a single conversation with Claude (claude.ai) from the assignment PDF: planning the architecture,
then generating, running and iterating on the code and tests in Claude's sandbox.

**To complete the submission requirement, export the full chat transcript** (claude.ai → the conversation → share/export)
and save it here as `docs/AI_TRANSCRIPT.md`; I can't attach it from inside the conversation.

Notable iterations visible in that transcript: (1) first replay showed sensor glitches firing alerts → added two-hour
confirmation and a single-hour-jump guard; (2) recovery was closing episodes late → relaxed the clear threshold and
re-checked recall; (3) message phrasing fixes ("since on Tuesday").
