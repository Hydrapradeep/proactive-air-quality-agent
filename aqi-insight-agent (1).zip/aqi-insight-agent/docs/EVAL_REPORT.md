# Evaluation: simulated replay (28 days, seed 7)

| Metric | Value |
|---|---|
| Recall: spike | 9/10 (0.9) |
| Recall: trend | 6/6 (1.0) |
| Recall: recovery | 10/15 (0.67) |
| Precision (alerts matching a real event) | 0.59 |
| Alerts sent (reference users) | 49 (TP 29, FP 20) |
| Alerts per station-day | 0.49 |
| Detection latency (hours after onset), median / max | 1.0 / 6.0 |
| Dedup: candidate hours -> sent / suppressed (all users) | 173 -> 59 / 114 |
| Naive 'AQI>100 every hour' alerter would send | 593 (5.88 per station-day) |

## False positives

| station | time (UTC) | kind | AQI | likely cause |
|---|---|---|---|---|
| delhi | 2026-09-17T16:00:00Z | elevated | 264 | unexplained_noise |
| delhi | 2026-09-17T23:00:00Z | recovery | 187 | recovery_without_matching_event |
| delhi | 2026-09-21T17:00:00Z | trend | 272 | unexplained_noise |
| delhi | 2026-09-22T00:00:00Z | recovery | 188 | recovery_without_matching_event |
| bengaluru | 2026-09-15T17:00:00Z | trend | 150 | unexplained_noise |
| bengaluru | 2026-09-16T02:00:00Z | recovery | 79 | recovery_without_matching_event |
| bengaluru | 2026-09-20T01:00:00Z | recovery | 82 | recovery_without_matching_event |
| bengaluru | 2026-09-24T00:00:00Z | trend | 125 | unexplained_noise |
| bengaluru | 2026-09-24T07:00:00Z | recovery | 85 | recovery_without_matching_event |
| london | 2026-09-25T08:00:00Z | recovery | 46 | recovery_without_matching_event |
| reykjavik | 2026-09-21T15:00:00Z | elevated | 36 | unexplained_noise |
| reykjavik | 2026-09-23T12:00:00Z | recovery | 18 | recovery_without_matching_event |
| los_angeles | 2026-09-08T21:00:00Z | elevated | 64 | unexplained_noise |
| los_angeles | 2026-09-09T08:00:00Z | recovery | 60 | recovery_without_matching_event |
| los_angeles | 2026-09-15T07:00:00Z | elevated | 73 | unexplained_noise |
| los_angeles | 2026-09-15T20:00:00Z | recovery | 54 | recovery_without_matching_event |
| los_angeles | 2026-09-16T01:00:00Z | trend | 75 | unexplained_noise |
| los_angeles | 2026-09-16T20:00:00Z | recovery | 58 | recovery_without_matching_event |
| los_angeles | 2026-09-18T11:00:00Z | recovery | 61 | recovery_without_matching_event |
| los_angeles | 2026-09-27T10:00:00Z | recovery | 63 | recovery_without_matching_event |
