# Decision / architecture note

## What "proactive" means here
The service never answers "what's the AQI?". Each hour, per user, it asks *"has something changed that this person would
want to know, that I haven't already told them?"* and stays silent otherwise. Silence is logged as deliberately as speech.

## 1. Detection: a small learned model, not thresholds
For each station we fit on the trailing 7 days (excluding the last 6 hours so an ongoing episode can't normalise itself):
a **diurnal profile** (24 shrunken hour-of-day offsets in log-AQI), a **robust baseline** (median) and a **noise scale σ**
(1.4826·MAD, floored at 0.12). Every reading becomes a z-score against *that station's own* normal for that hour.
A one-sided **CUSUM** (k=0.75, h=6, capped at 2h) over the z-scores is the change-point alarm.

| Candidate | Fires when (all must hold) |
|---|---|
| spike | z ≥ 3.25 now **and** previous hour z ≥ 0.75·3.25 (confirmation) and ≥1.5× the median of hours t-8..t-4 and ≥12 AQI above expected |
| trend | CUSUM alarm, z ≥ 2.0 with previous hour confirming, ≥3 of 4 hourly steps up, Theil-Sen slope > 0, rise ≥25% and ≥12 pts over 5h, not a single-hour ×2.2 jump |
| elevated | CUSUM alarm and z ≥ 2.5 for two consecutive hours (a shift that is no longer rising) |
| recovery | only inside an alerted episode: z ≤ 1.0 for 3 hours and AQI ≤ 75% of the episode peak (hysteresis vs. entry) |

**Different baselines:** σ and the diurnal shape are learned per station, so a 20→45 jump in Reykjavik is "unusual" while
Delhi needs a much bigger move. A per-user `sensitivity` divides the z thresholds (1.3 = lower bar). Absolute guards
(≥12 AQI above expected, AQI ≥30) stop statistically-significant-but-meaningless blips in very clean air.

**False positives / misses:** invalid values are flagged; 6+ identical consecutive values are flagged `stuck` and excluded;
missing hours break confirmation rather than being interpolated; stale feeds (>3h) produce a logged `stale_data` decision.
The cost of confirmation is ~1h latency (median detection latency in the sim eval: 1h).

## 2. Dedup / rate limiting (policy.py)
State per user: status, episode id/peak, last alert (kind, band, AQI, time), streak counter, cooldown, last recovery.
* New worsening candidate while NORMAL → send, unless still in cooldown from a recent alert and not worse (`flap_cooldown`).
* Inside an episode, speak again only for **band escalation** (≥1h gap) or **major worsening** (≥35% and ≥30 pts, only after cooldown).
  Everything else is `duplicate_ongoing_episode`. Six bad hours in a row = one message.
* Recovery is sent once, only if we alerted in that episode.
* **Cooldown with back-off/decay:** 3h → 6h → 12h → 24h per alert in a streak; the streak decays by 1 per 12h of silence.

## 3. Messages
Context object (what changed, how unusual vs this hour's norm, when it started, highest since X, previous alert and
whether this is an escalation, episode peak for recoveries) + one action chosen from the user's activity (runner / cyclist /
parent / commuter) and the AQI band. If `ANTHROPIC_API_KEY` is set an LLM rewrites it under strict rules (≤2 sentences, one
action, reference past context); output is validated and any failure falls back to the template, so a message is never lost.

## 4. Observability
`decisions` has a row for **every** evaluation, with fitted-model summary, thresholds actually used for that user, every
check's pass/fail + metrics, the 24h window with z-scores, policy state before/after, and a link to the notification.

## 5. Evaluation (bonus)
`evaluate.py` replays history hour by hour through the identical pipeline (queries only see data ≤ "now") and scores against
labels. Sim result (28 days × 5 cities, seed 7, see `EVAL_REPORT.md`): spike 9/10, trend 6/6, recovery 10/15, precision 0.59,
0.49 alerts per station-day vs 5.88 for a naive "AQI>100 every hour" alerter. Sensor glitches and stuck sensors produced
no alerts. Remaining false positives are natural noise excursions in the simulated series.

## Trade-offs I'd revisit
* SQLite + in-process scheduler: fine for a handful of stations; Postgres + a real queue for scale.
* One pooled model per station; per-user thresholds are multipliers, not separately learned.
* z-scores in log space assume roughly lognormal PM2.5; wildfire/dust events with long durations slowly re-baseline.
* Quiet hours / delivery channel are out of scope; the notification table is the "outbox".
