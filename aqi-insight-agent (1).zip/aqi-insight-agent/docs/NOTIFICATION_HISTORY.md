# Notification history (simulated replay)

59 notifications sent to 6 users over 28 days (7 days burn-in used for model fitting). Each row links to its decision id; open `/api/decisions/<id>` in the running service for the full trace.

## dana-la

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-08T21:00:00Z | elevated | 64 | Air in Los Angeles is running well above normal since last night: AQI 64, roughly 34% above the usual for this hour. Still fine to run, but stick to quieter routes away from traffic. | #2542 |
| 2026-09-09T08:00:00Z | recovery | 60 | Air in Los Angeles has cleared up: AQI 60, down from a peak of 80 yesterday evening. It was elevated for about 11 hours. Good time to head out for a run. | #2553 |
| 2026-09-10T19:00:00Z | elevated | 77 | Air in Los Angeles is running well above normal since 11 AM: AQI 77, roughly 63% above the usual for this hour. It's the highest reading since Tuesday. Still fine to run, but stick to quieter routes away from traffic. | #2588 |
| 2026-09-11T07:00:00Z | recovery | 57 | Air in Los Angeles has cleared up: AQI 57, down from a peak of 77 yesterday morning. It was elevated for about 12 hours. Good time to head out for a run. | #2600 |
| 2026-09-15T07:00:00Z | elevated | 73 | Air in Los Angeles is running well above normal since yesterday evening: AQI 73, roughly 28% above the usual for this hour. It's the highest reading since Saturday. Still fine to run, but stick to quieter routes away from traffic. | #2696 |
| 2026-09-15T20:00:00Z | recovery | 54 | Air in Los Angeles has cleared up: AQI 54, down from a peak of 73 this morning. It was elevated for about 13 hours. Good time to head out for a run. | #2709 |
| 2026-09-16T01:00:00Z | trend | 75 | Los Angeles's air has been climbing for the past several hours (AQI 60 to 75). It's the highest reading since Saturday. Fine for a run; a park beats a main road right now. | #2714 |
| 2026-09-16T20:00:00Z | recovery | 58 | Air in Los Angeles has cleared up: AQI 58, down from a peak of 84 yesterday morning. It was elevated for about 19 hours. Good time to head out for a run. | #2733 |
| 2026-09-18T02:00:00Z | spike | 104 | Los Angeles's air quality spiked sharply to AQI 104 (roughly 61% above the usual for this hour). It's the highest reading since Tuesday. Consider moving your run indoors, or keep it short and easy. | #2763 |
| 2026-09-18T11:00:00Z | recovery | 61 | Air in Los Angeles has cleared up: AQI 61, down from a peak of 108 yesterday evening. It was elevated for about 9 hours. Good window to get that run in. | #2772 |
| 2026-09-20T20:00:00Z | elevated | 89 | Air in Los Angeles is running well above normal since 7 AM: AQI 89, roughly 64% above the usual for this hour. It's the highest reading since Thursday. Fine for a run; a park beats a main road right now. | #2829 |
| 2026-09-21T07:00:00Z | recovery | 65 | Air in Los Angeles has cleared up: AQI 65, down from a peak of 89 yesterday afternoon. It was elevated for about 11 hours. Good time to head out for a run. | #2840 |
| 2026-09-26T10:00:00Z | trend | 87 | Air in Los Angeles has been getting steadily worse over the last few hours (AQI 61 to 87). It's the highest reading since Sunday. Still fine to run, but stick to quieter routes away from traffic. | #2963 |
| 2026-09-26T13:00:00Z | trend | 103 | Air in Los Angeles has been getting steadily worse over the last few hours (AQI 77 to 103). That's worse than the AQI 87 I flagged overnight. If you run, keep it light and shorter than usual. | #2966 |
| 2026-09-27T10:00:00Z | recovery | 63 | Air in Los Angeles has cleared up: AQI 63, down from a peak of 121 yesterday morning. It was elevated for about 24 hours. Good window to get that run in. | #2987 |

## tom-london

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-10T17:00:00Z | spike | 117 | Air in London just jumped: AQI 117, about 2.2x the usual for this hour. It's the highest in the 9 days we've tracked. If you cycle, take quieter back streets and consider a mask. | #1578 |
| 2026-09-11T06:00:00Z | recovery | 59 | Air in London has cleared up: AQI 59, down from a peak of 118 yesterday evening. It was elevated for about 13 hours. Good time to get back on the bike. | #1591 |
| 2026-09-15T15:00:00Z | spike | 84 | Air in London just jumped: AQI 84, roughly 65% above the usual for this hour. It's the highest reading since Thursday. Fine to ride; pick the low-traffic route. | #1696 |
| 2026-09-16T02:00:00Z | recovery | 55 | Air in London has cleared up: AQI 55, down from a peak of 84 yesterday afternoon. It was elevated for about 11 hours. Good time to get back on the bike. | #1707 |
| 2026-09-18T17:00:00Z | trend | 74 | London's air has been climbing for the past several hours (AQI 49 to 74). It's the highest reading since Tuesday. Cycling is fine, but quieter streets will keep your exposure down. | #1770 |
| 2026-09-19T00:00:00Z | recovery | 47 | Air in London has cleared up: AQI 47, down from a peak of 75 yesterday evening. It was elevated for about 7 hours. Good time to get back on the bike. | #1777 |
| 2026-09-25T03:00:00Z | elevated | 77 | Air in London is running well above normal since 3 AM: AQI 77, roughly 47% above the usual for this hour. It's the highest reading since Sunday. Cycling is fine, but quieter streets will keep your exposure down. | #1924 |
| 2026-09-25T08:00:00Z | recovery | 46 | Air in London has cleared up: AQI 46, down from a peak of 77 overnight. It was elevated for about 5 hours. Good time to get back on the bike. | #1929 |

## meera-blr

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-11T00:00:00Z | spike | 166 | Air in Bengaluru just jumped: AQI 166, about 2.2x the usual for this hour. It's the highest in the 10 days we've tracked. Hold off on outdoor play and keep windows shut for now. | #1081 |
| 2026-09-11T17:00:00Z | recovery | 91 | Air in Bengaluru has cleared up: AQI 91, down from a peak of 166 overnight. It was elevated for about 17 hours. Good time to open the windows and head back to the park. | #1098 |
| 2026-09-15T17:00:00Z | trend | 150 | Bengaluru's air has been climbing for the past several hours (AQI 111 to 150). It's the highest reading since Saturday. Shorten outdoor play and keep an eye on it. | #1194 |
| 2026-09-16T02:00:00Z | recovery | 79 | Air in Bengaluru has cleared up: AQI 79, down from a peak of 150 last night. It was elevated for about 9 hours. Fine to take the kids out again. | #1203 |
| 2026-09-18T08:00:00Z | elevated | 109 | Air in Bengaluru is running well above normal since 11 AM: AQI 109, roughly 46% above the usual for this hour. It's the highest reading since Wednesday. Keep outdoor play short and windows closed for now. | #1257 |
| 2026-09-20T01:00:00Z | recovery | 82 | Air in Bengaluru has cleared up: AQI 82, down from a peak of 112 on Friday. It was elevated for about 41 hours. Good time to open the windows and head back to the park. | #1298 |
| 2026-09-24T00:00:00Z | trend | 125 | Bengaluru's air has been climbing for the past several hours (AQI 93 to 125). Shorten outdoor play and keep an eye on it. | #1393 |
| 2026-09-24T07:00:00Z | recovery | 85 | Air in Bengaluru has cleared up: AQI 85, down from a peak of 125 yesterday afternoon. It was elevated for about 7 hours. Good time to open the windows and head back to the park. | #1400 |

## asha-delhi

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-13T19:00:00Z | elevated | 252 | Air in Delhi is running well above normal since yesterday evening: AQI 252, roughly 40% above the usual for this hour. It's the highest reading since Thursday. Skip the outdoor run today; a treadmill session is the safer swap. | #279 |
| 2026-09-13T23:00:00Z | elevated | 312 | Air in Delhi is running well above normal since yesterday evening: AQI 312, about 1.8x the usual for this hour. That's worse than the AQI 252 I flagged overnight. Skip the outdoor run today; a treadmill session is the safer swap. | #287 |
| 2026-09-14T11:00:00Z | recovery | 169 | Air in Delhi has cleared up: AQI 169, down from a peak of 500 this morning. It was elevated for about 16 hours. Good time to head out for a run. | #311 |
| 2026-09-17T16:00:00Z | elevated | 264 | Air in Delhi is running well above normal since 4 PM: AQI 264, roughly 43% above the usual for this hour. It's the highest reading since Monday. Move today's run indoors or take a rest day. | #465 |
| 2026-09-17T23:00:00Z | recovery | 187 | Air in Delhi has cleared up: AQI 187, down from a peak of 264 last night. It was elevated for about 7 hours. Good time to head out for a run. | #479 |
| 2026-09-18T14:00:00Z | spike | 361 | Delhi's air quality spiked sharply to AQI 361 (about 2.1x the usual for this hour). It's the highest reading since Monday. Skip the outdoor run today; a treadmill session is the safer swap. | #509 |
| 2026-09-18T17:00:00Z | spike | 500 | Air in Delhi just jumped: AQI 500, about 2.4x the usual for this hour. That's worse than the AQI 361 I flagged this evening. Skip the outdoor run today; a treadmill session is the safer swap. | #515 |
| 2026-09-19T02:00:00Z | recovery | 182 | Air in Delhi has cleared up: AQI 182, down from a peak of 500 last night. It was elevated for about 12 hours. Good window to get that run in. | #533 |
| 2026-09-21T17:00:00Z | trend | 272 | Air in Delhi has been getting steadily worse over the last few hours (AQI 198 to 272). It's the highest reading since Saturday. Move today's run indoors or take a rest day. | #659 |
| 2026-09-22T00:00:00Z | recovery | 188 | Air in Delhi has cleared up: AQI 188, down from a peak of 272 last night. It was elevated for about 7 hours. Good window to get that run in. | #673 |
| 2026-09-23T20:00:00Z | spike | 408 | Air in Delhi just jumped: AQI 408, about 2.1x the usual for this hour. It's the highest reading since Saturday. Move today's run indoors or take a rest day. | #761 |
| 2026-09-24T21:00:00Z | recovery | 199 | Air in Delhi has cleared up: AQI 199, down from a peak of 408 last night. It was elevated for about 25 hours. Good window to get that run in. | #811 |

## vikram-delhi

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-13T20:00:00Z | elevated | 251 | Air in Delhi is running well above normal since yesterday evening: AQI 251, roughly 46% above the usual for this hour. It's the highest reading since Thursday. Mask up (N95) for the commute and keep windows shut. | #282 |
| 2026-09-14T00:00:00Z | spike | 500 | Delhi's air quality spiked sharply to AQI 500 (about 2.9x the usual for this hour). That's worse than the AQI 251 I flagged overnight. Mask up (N95) for the commute and keep windows shut. | #290 |
| 2026-09-14T11:00:00Z | recovery | 169 | Air in Delhi has cleared up: AQI 169, down from a peak of 500 this morning. It was elevated for about 15 hours. Good time to air the house out. | #312 |
| 2026-09-17T17:00:00Z | trend | 251 | Air in Delhi has been getting steadily worse over the last few hours (AQI 197 to 251). It's the highest reading since Monday. Mask up (N95) for the commute and keep windows shut. | #468 |
| 2026-09-17T23:00:00Z | recovery | 187 | Air in Delhi has cleared up: AQI 187, down from a peak of 251 last night. It was elevated for about 6 hours. Open the windows and let fresh air in. | #480 |
| 2026-09-18T14:00:00Z | spike | 361 | Air in Delhi just jumped: AQI 361, about 2.1x the usual for this hour. It's the highest reading since Monday. Wear a fitted N95 for the commute and run your purifier on high at home. | #510 |
| 2026-09-18T17:00:00Z | spike | 500 | Delhi's air quality spiked sharply to AQI 500 (about 2.4x the usual for this hour). That's worse than the AQI 361 I flagged this evening. Wear a fitted N95 for the commute and run your purifier on high at home. | #516 |
| 2026-09-19T02:00:00Z | recovery | 182 | Air in Delhi has cleared up: AQI 182, down from a peak of 500 last night. It was elevated for about 12 hours. Open the windows and let fresh air in. | #534 |
| 2026-09-23T20:00:00Z | spike | 408 | Delhi's air quality spiked sharply to AQI 408 (about 2.1x the usual for this hour). It's the highest reading since Saturday. Wear a fitted N95 for the commute and run your purifier on high at home. | #762 |
| 2026-09-24T21:00:00Z | recovery | 199 | Air in Delhi has cleared up: AQI 199, down from a peak of 408 last night. It was elevated for about 25 hours. Good time to air the house out. | #812 |

## sigrun-rey

| time (UTC) | kind | AQI | message | decision |
|---|---|---|---|---|
| 2026-09-15T17:00:00Z | trend | 46 | Reykjavik's air has been climbing for the past several hours (AQI 22 to 46). It's the highest reading since Saturday. Fine for a run; a park beats a main road right now. | #2202 |
| 2026-09-15T18:00:00Z | trend | 55 | Air in Reykjavik has been getting steadily worse over the last few hours (AQI 23 to 55). That's worse than the AQI 46 I flagged this evening. Fine for a run; a park beats a main road right now. | #2203 |
| 2026-09-16T02:00:00Z | recovery | 25 | Air in Reykjavik has cleared up: AQI 25, down from a peak of 58 yesterday evening. It was elevated for about 9 hours. Good window to get that run in. | #2211 |
| 2026-09-21T15:00:00Z | elevated | 36 | Air in Reykjavik is running well above normal since 11 AM: AQI 36, about 1.8x the usual for this hour. Fine for a run; a park beats a main road right now. | #2344 |
| 2026-09-22T03:00:00Z | trend | 51 | Air in Reykjavik has been getting steadily worse over the last few hours (AQI 37 to 51). That's worse than the AQI 36 I flagged yesterday afternoon. Still fine to run, but stick to quieter routes away from traffic. | #2356 |
| 2026-09-23T12:00:00Z | recovery | 18 | Air in Reykjavik has cleared up: AQI 18, down from a peak of 59 last night. It was elevated for about 45 hours. Good window to get that run in. | #2389 |

## What dedup swallowed

| reason | count |
|---|---|
| duplicate_ongoing_episode | 109 |
| worsening_but_in_cooldown | 5 |
