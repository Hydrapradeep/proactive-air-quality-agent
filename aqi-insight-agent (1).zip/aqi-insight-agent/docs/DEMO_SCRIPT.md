# Demo video script (~5 min)

Setup: `python -m aqi_agent demo`, then `AQI_DB=demo.db AQI_SCHEDULER=off AQI_SOURCE=none python -m aqi_agent serve`.
Terminal: `python -m scripts.demo_walkthrough` (press Enter between sections). Browser tabs: `/`, `docs/EVAL_REPORT.md`.

| Time | Screen | Say |
|---|---|---|
| 0:00 | README diagram | "This service watches hourly PM2.5 from OpenAQ for five cities and decides when a user is worth interrupting. Silence is the default; it speaks only when something meaningful changes." |
| 0:30 | Walkthrough section 1 | "Each station fits its own baseline and noise level from the last 7 days. A spike alert needs roughly AQI 270 in Delhi but only about 65 in Reykjavik, so 'unusual' is relative to the city. Users also have a sensitivity multiplier." |
| 1:15 | `detector.py` / DECISIONS.md table | "A CUSUM change-point alarm runs over the z-scores. Spike, trend, elevated and recovery each need several conditions to hold, and a confirming previous hour." |
| 2:00 | Walkthrough section 2 | "Here the air stayed unusual for many hours. One notification went out; the rest were suppressed as duplicates until a recovery message. Cooldowns back off 3h, 6h, 12h, 24h and decay after quiet periods." |
| 2:45 | Walkthrough section 3 | "A single-hour reading of AQI 500 did not fire, because the previous hour wasn't elevated. Sensor glitches are a classic false positive." |
| 3:15 | `NOTIFICATION_HISTORY.md` | "Messages reference past context, like an earlier alert or highest-since, and give one action tailored to the user. An LLM writes them if a key is set, otherwise a template." |
| 3:45 | Dashboard, then `/api/decisions/121` | "To debug a missing or bad nudge: the fitted model, each check with its numbers, the 24h window, and the user's state before and after." |
| 4:30 | `EVAL_REPORT.md` | "Replaying history through the same pipeline: spikes 9/10, trends 6/6, recoveries 10/15, 0.49 alerts per station-day vs 5.88 for a naive threshold alerter. This is on simulated data with ground truth, since OpenAQ wasn't reachable where I built it." |
